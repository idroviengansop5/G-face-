# G-face — Guide de mise en route

Application : **G-face**
Propriétaire : **Idrovie Rodéo Ngansop**
ID application Android : `com.idrovie.gface`

G-face est un réseau social : création de compte, profil avec statut, publication de vidéos, likes, commentaires, et messagerie privée en temps réel.

Tout le code est déjà prêt dans le dossier `www/`. Il te reste deux étapes que **toi seul peux faire** (elles demandent ton compte Google et ton ordinateur) : créer le projet Firebase (le "serveur"), puis générer l'APK Android avec Capacitor.

---

## ÉTAPE 1 — Créer le projet Firebase (gratuit)

1. Va sur https://console.firebase.google.com et connecte-toi avec un compte Google.
2. Clique sur **Ajouter un projet**, nomme-le par exemple `gface`, puis termine la création (tu peux désactiver Google Analytics, ce n'est pas nécessaire).
3. Dans le menu de gauche, active ces 3 services :
   - **Authentication** → onglet "Sign-in method" → active **Adresse e-mail/Mot de passe**.
   - **Firestore Database** → **Créer une base de données** → mode **production** → choisis une région proche (ex: `eur3` Europe).
   - **Storage** → **Commencer** → mode **production**.
4. Toujours dans la console, va dans **Paramètres du projet** (icône ⚙️ en haut à gauche) → onglet **Général** → section "Vos applications" → clique sur l'icône **Web `</>`**.
   - Nomme l'app `G-face Web`, ne coche pas Firebase Hosting.
   - Firebase t'affiche un objet `firebaseConfig` avec des clés (`apiKey`, `authDomain`, etc.). **Copie-le**.
5. Ouvre le fichier `www/js/firebase-config.js` dans le projet et remplace les valeurs `"REMPLACE_MOI"` par celles que Firebase t'a données.
6. Publie les règles de sécurité :
   - Firestore Database → onglet **Règles** → colle le contenu du fichier `firestore.rules` fourni → **Publier**.
   - Storage → onglet **Règles** → colle le contenu du fichier `storage.rules` fourni → **Publier**.

À ce stade, l'application est fonctionnelle. Tu peux déjà la tester dans un navigateur en ouvrant `www/index.html` (double-clique dessus), à condition que ton navigateur autorise les requêtes locales — sinon utilise un petit serveur local :
```
cd gface/www
npx serve .
```

---

## ÉTAPE 2 — Générer l'application Android avec Capacitor

Prérequis sur ton ordinateur : **Node.js** (https://nodejs.org) et **Android Studio** (https://developer.android.com/studio).

Depuis le dossier `gface/` (celui qui contient `package.json`) :

```bash
# 1. Installer les dépendances
npm install

# 2. Initialiser Capacitor (déjà configuré dans capacitor.config.json, cette commande confirme juste la config)
npx cap init "G-face" "com.idrovie.gface" --web-dir=www

# 3. Ajouter la plateforme Android
npx cap add android

# 4. Copier le code web dans le projet Android
npx cap copy android

# 5. Ouvrir le projet dans Android Studio
npx cap open android
```

Dans Android Studio :
1. Attends la fin de la synchronisation Gradle (barre de progression en bas).
2. Menu **Build → Generate Signed Bundle / APK** pour créer ton APK signé (à installer sur un téléphone ou publier sur le Play Store), ou clique simplement sur ▶️ **Run** pour tester sur un émulateur/téléphone connecté.

Chaque fois que tu modifies le code dans `www/`, relance `npx cap copy android` avant de rebuilder dans Android Studio.

---

## Icônes et écran de démarrage

Comme pour G-ciml, on peut générer les icônes et le splash screen personnalisés une fois que tu as une image de logo G-face. Dis-le-moi et je les prépare (dossier `www/icons/` déjà prévu).

---

## Structure du projet

```
gface/
├── www/                     ← code de l'application (à copier sur Android)
│   ├── index.html
│   ├── css/style.css
│   └── js/
│       ├── firebase-config.js   ← À REMPLIR avec tes clés Firebase
│       ├── app.js               ← authentification, navigation
│       ├── feed.js              ← fil vidéo, likes, commentaires
│       ├── upload.js            ← publication de vidéos
│       ├── profile.js           ← profil, statut, photo
│       └── messages.js          ← recherche, discussions, chat temps réel
├── firestore.rules          ← règles de sécurité base de données
├── storage.rules            ← règles de sécurité fichiers (vidéos/photos)
├── capacitor.config.json
└── package.json
```

## Fonctionnalités incluses (v1)

- ✅ Création de compte / connexion (e-mail + mot de passe)
- ✅ Profil : photo, statut, bio
- ✅ Publication de vidéos avec légende
- ✅ Fil d'actualité en temps réel
- ✅ Likes
- ✅ Commentaires
- ✅ Recherche d'utilisateurs
- ✅ Messagerie privée en temps réel

## ÉTAPE 2 (bis) — Générer l'APK depuis un téléphone, sans ordinateur

Si tu n'as pas d'ordinateur, GitHub peut fabriquer l'APK à ta place, gratuitement, dans son "cloud". Le fichier `.github/workflows/build.yml` est déjà prêt pour ça. Voici comment faire, entièrement depuis le navigateur de ton téléphone :

1. **Crée un compte** sur https://github.com (bouton "Sign up").
2. Une fois connecté, crée un nouveau dépôt (bouton **+** en haut à droite → **New repository**) : nomme-le `gface`, laisse-le **Public**, ne coche aucune case, puis **Create repository**.
3. Sur ton téléphone, ouvre le zip `gface.zip` avec ton application de fichiers (elle doit pouvoir l'extraire — sur Android : "Files"/"Mes fichiers" ; sur iPhone : l'app "Fichiers").
4. Dans ton nouveau dépôt GitHub, clique sur **Add file → Create new file**.
   - Dans le champ du nom de fichier, tape le chemin complet, par exemple : `www/index.html`
   - Ouvre le fichier correspondant dans ton gestionnaire de fichiers, copie tout son contenu, colle-le dans la grande zone de texte de GitHub.
   - Descends en bas de page, clique **Commit changes**.
   - Répète cette opération pour **chaque fichier** du projet (utilise les mêmes chemins que dans la liste plus bas). Tape bien le chemin avec les `/` : GitHub crée les dossiers automatiquement.
5. **Important** : pour le fichier `www/js/firebase-config.js`, colle son contenu puis remplace les `"REMPLACE_MOI"` par tes vraies clés Firebase avant de faire "Commit changes".
6. Une fois tous les fichiers ajoutés (liste ci-dessous), va dans l'onglet **Actions** du dépôt. Le robot de construction démarre automatiquement dès qu'un fichier est ajouté sur la branche `main`. Sinon, clique sur le workflow **Build G-face APK** puis **Run workflow**.
7. Attends 3 à 6 minutes que le rond jaune 🟡 devienne une coche verte ✅.
8. Clique sur le résultat du workflow terminé, descends jusqu'à **Artifacts**, télécharge **gface-apk** (c'est un zip contenant l'APK).
9. Extrais ce zip sur ton téléphone, tu obtiens `app-debug.apk`. Ouvre-le pour l'installer (Android peut demander d'autoriser "sources inconnues" la première fois — accepte).

**Fichiers à créer sur GitHub (chemin exact) :**
```
www/index.html
www/css/style.css
www/js/firebase-config.js
www/js/app.js
www/js/feed.js
www/js/upload.js
www/js/profile.js
www/js/messages.js
firestore.rules
storage.rules
capacitor.config.json
package.json
.github/workflows/build.yml
```

Une fois cette première version installée, pour toute future modification : édite les fichiers directement sur GitHub (icône crayon ✎ sur chaque fichier), commite, et le workflow refabrique automatiquement un nouvel APK.

## Prochaines améliorations possibles

- Notifications push (nouveaux likes, commentaires, messages)
- Partage de statuts éphémères (type "story")
- Modération de contenu
- Pagination / défilement infini du fil
- Compression vidéo côté client avant envoi
