// ============================================================
// G-face — profanity-filter.js : masque les mots grossiers courants
// ============================================================

// Liste volontairement modeste de mots grossiers courants en français
// (le but est de filtrer les insultes de base, pas d'être exhaustif)
const PROFANITY_LIST = [
  'merde', 'putain', 'connard', 'connasse', 'salope', 'enculé', 'enculée',
  'batard', 'bâtard', 'pute', 'ntm', 'niquer', 'nique', 'foutre', 'con',
  'connerie', 'chier', 'branleur', 'encule'
];

const PROFANITY_REGEX = new RegExp(
  '\\b(' + PROFANITY_LIST.map(w => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')\\b',
  'gi'
);

function filterProfanity(text){
  if (!text) return text;
  return text.replace(PROFANITY_REGEX, (match) => match[0] + '*'.repeat(Math.max(match.length - 1, 1)));
}
