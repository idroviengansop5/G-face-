// ============================================================
// G-face — discover.js : recherche de publications et d'utilisateurs
// ============================================================

let discoverDebounce = null;

document.getElementById('discover-search-input').addEventListener('input', (e) => {
  clearTimeout(discoverDebounce);
  const term = e.target.value.trim().toLowerCase();
  discoverDebounce = setTimeout(() => runDiscoverSearch(term), 300);
});

async function runDiscoverSearch(term){
  const list = document.getElementById('discover-list');

  if (!term){
    await renderDiscoverDefault();
    return;
  }

  list.innerHTML = '<p class="empty-sub" style="text-align:center;">Recherche...</p>';

  // Utilisateurs correspondants
  const usersSnap = await db.collection('users')
    .where('usernameLower', '>=', term)
    .where('usernameLower', '<=', term + '\uf8ff')
    .limit(10)
    .get();

  // Publications récentes (les 100 plus récentes), filtrées côté client sur légende/auteur
  const postsSnap = await db.collection('posts')
    .orderBy('createdAt', 'desc')
    .limit(100)
    .get();

  const matchingPosts = [];
  postsSnap.forEach(doc => {
    const p = doc.data();
    const haystack = ((p.caption || '') + ' ' + (p.username || '')).toLowerCase();
    if (haystack.includes(term)) matchingPosts.push({ id: doc.id, data: p });
  });

  list.innerHTML = '';

  if (!usersSnap.empty){
    const usersHeader = document.createElement('h3');
    usersHeader.className = 'view-title';
    usersHeader.textContent = 'Utilisateurs';
    list.appendChild(usersHeader);

    usersSnap.forEach(doc => {
      if (doc.id === currentUser.uid) return;
      const u = doc.data();
      const row = document.createElement('div');
      row.className = 'user-result-row';
      row.innerHTML = `
        <img class="avatar-sm" src="${u.photoURL || defaultAvatar()}" />
        <span>${escapeHtml(u.username)}</span>
      `;
      row.addEventListener('click', () => openChat(doc.id, u.username));
      list.appendChild(row);
    });
  }

  if (matchingPosts.length > 0){
    const postsHeader = document.createElement('h3');
    postsHeader.className = 'view-title';
    postsHeader.style.marginTop = '20px';
    postsHeader.textContent = 'Publications';
    list.appendChild(postsHeader);

    matchingPosts.forEach(p => list.appendChild(buildPostCard(p.id, p.data)));
  }

  if (usersSnap.empty && matchingPosts.length === 0){
    list.innerHTML = '<p class="empty-sub" style="text-align:center;">Aucun résultat.</p>';
  }
}

async function renderDiscoverDefault(){
  const list = document.getElementById('discover-list');
  list.innerHTML = '<p class="empty-sub" style="text-align:center;">Chargement...</p>';

  // On récupère les publications récentes et on les trie par popularité (nombre de likes) côté client
  const snap = await db.collection('posts').orderBy('createdAt', 'desc').limit(50).get();

  list.innerHTML = '';

  if (snap.empty){
    list.innerHTML = '<p class="empty-sub" style="text-align:center;">Aucune publication à découvrir pour l\'instant.</p>';
    return;
  }

  const posts = [];
  snap.forEach(doc => posts.push({ id: doc.id, data: doc.data() }));
  posts.sort((a, b) => (b.data.likes?.length || 0) - (a.data.likes?.length || 0));

  posts.slice(0, 20).forEach(p => list.appendChild(buildPostCard(p.id, p.data)));
}
