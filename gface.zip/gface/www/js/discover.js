// ============================================================
// G-face — discover.js : recherche de publications et d'utilisateurs
// ============================================================

let discoverDebounce = null;

document.getElementById('discover-search-input').addEventListener('input', (e) => {
  clearTimeout(discoverDebounce);
  const term = e.target.value.trim().toLowerCase();
  discoverDebounce = setTimeout(() => runDiscoverSearch(term), 300);
});

document.getElementById('discover-mic-btn').addEventListener('click', (e) => {
  startDictation((text) => {
    const input = document.getElementById('discover-search-input');
    input.value = text;
    runDiscoverSearch(text.trim().toLowerCase());
  }, e.currentTarget);
});

async function runDiscoverSearch(term){
  const list = document.getElementById('discover-list');

  if (!term){
    await renderDiscoverDefault();
    return;
  }

  list.innerHTML = '<p class="empty-sub" style="text-align:center;">Recherche...</p>';

  // Utilisateurs correspondants
  const usersSnap = await db.collection('users')
    .where('usernameLower', '>=', term)
    .where('usernameLower', '<=', term + '\uf8ff')
    .limit(10)
    .get();

  // Publications récentes (les 100 plus récentes), filtrées côté client sur légende/auteur
  const postsSnap = await db.collection('posts')
    .orderBy('createdAt', 'desc')
    .limit(100)
    .get();

  const matchingPosts = [];
  postsSnap.forEach(doc => {
    const p = doc.data();
    const haystack = ((p.caption || '') + ' ' + (p.username || '')).toLowerCase();
    if (haystack.includes(term)) matchingPosts.push({ id: doc.id, data: p });
  });

  list.innerHTML = '';

  if (!usersSnap.empty){
    const usersHeader = document.createElement('h3');
    usersHeader.className = 'view-title';
    usersHeader.textContent = 'Utilisateurs';
    list.appendChild(usersHeader);

    usersSnap.forEach(doc => {
      if (doc.id === currentUser.uid) return;
      const u = doc.data();
      const row = document.createElement('div');
      row.className = 'user-result-row';
      row.innerHTML = `
        <img class="avatar-sm" src="${u.photoURL || defaultAvatar()}" />
        <span>${escapeHtml(u.username)}</span>
      `;
      row.addEventListener('click', () => openUserProfile(doc.id));
      list.appendChild(row);
    });
  }

  if (matchingPosts.length > 0){
    const postsHeader = document.createElement('h3');
    postsHeader.className = 'view-title';
    postsHeader.style.marginTop = '20px';
    postsHeader.textContent = 'Publications';
    list.appendChild(postsHeader);

    matchingPosts.forEach(p => list.appendChild(buildPostCard(p.id, p.data)));
  }

  if (usersSnap.empty && matchingPosts.length === 0){
    list.innerHTML = '<p class="empty-sub" style="text-align:center;">Aucun résultat.</p>';
  }
}

async function renderDiscoverDefault(){
  const list = document.getElementById('discover-list');
  list.innerHTML = '<p class="empty-sub" style="text-align:center;">Chargement...</p>';

  await renderSuggestedAccounts();

  // On récupère les publications récentes et on les trie par popularité (nombre de likes) côté client
  const snap = await db.collection('posts').orderBy('createdAt', 'desc').limit(50).get();

  list.innerHTML = '';

  if (snap.empty){
    list.innerHTML = '<p class="empty-sub" style="text-align:center;">Aucune publication à découvrir pour l\'instant.</p>';
    return;
  }

  const posts = [];
  snap.forEach(doc => posts.push({ id: doc.id, data: doc.data() }));
  posts.sort((a, b) => (b.data.likes?.length || 0) - (a.data.likes?.length || 0));

  posts.slice(0, 20).forEach(p => list.appendChild(buildPostCard(p.id, p.data)));
}

async function renderSuggestedAccounts(){
  const row = document.getElementById('suggested-accounts-row');
  row.innerHTML = '';

  try{
    const followingSnap = await db.collection('follows').where('followerUid', '==', currentUser.uid).get();
    const alreadyFollowing = new Set(followingSnap.docs.map(d => d.data().targetUid));

    const usersSnap = await db.collection('users').orderBy('createdAt', 'desc').limit(30).get();

    const suggestions = [];
    usersSnap.forEach(doc => {
      if (doc.id === currentUser.uid) return;
      if (blockedUids.has(doc.id)) return;
      if (alreadyFollowing.has(doc.id)) return;
      suggestions.push({ id: doc.id, ...doc.data() });
    });

    if (suggestions.length === 0) return;

    const header = document.createElement('p');
    header.className = 'empty-sub';
    header.style.margin = '0 0 8px 2px';
    header.textContent = 'Suggestions pour toi';
    row.appendChild(header);

    const scrollRow = document.createElement('div');
    scrollRow.style.display = 'flex';
    scrollRow.style.gap = '10px';
    scrollRow.style.overflowX = 'auto';

    suggestions.slice(0, 10).forEach(u => {
      const card = document.createElement('div');
      card.className = 'suggestion-card';
      card.innerHTML = `
        <img class="avatar-sm" src="${u.photoURL || defaultAvatar()}" style="width:48px; height:48px;" />
        <span class="story-label">${escapeHtml(u.username)}</span>
        <button class="btn btn-small suggestion-follow-btn">Suivre</button>
      `;
      card.querySelector('img').addEventListener('click', () => openUserProfile(u.id));
      card.querySelector('.suggestion-follow-btn').addEventListener('click', async (e) => {
        e.stopPropagation();
        await followUser(u.id, !!u.isPrivate);
        card.querySelector('.suggestion-follow-btn').textContent = u.isPrivate ? 'Demande envoyée' : 'Abonné(e) ✓';
        card.querySelector('.suggestion-follow-btn').disabled = true;
      });
      scrollRow.appendChild(card);
    });

    row.appendChild(scrollRow);
  }catch(err){
    console.error('Erreur suggestions:', err);
  }
}
