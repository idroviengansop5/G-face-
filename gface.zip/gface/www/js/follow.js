// ============================================================
// G-face — follow.js : profils publics, abonnements, comptes privés
// ============================================================

let viewedProfileUid = null;
let followRequestsUnsubscribe = null;

document.getElementById('user-profile-back-btn').addEventListener('click', () => {
  switchView('discover');
});

document.getElementById('follow-list-back-btn').addEventListener('click', () => {
  switchView(followListReturnView);
});

let followListReturnView = 'discover';

async function loadFollowCounts(uid, followersElId, followingElId){
  const followersEl = document.getElementById(followersElId);
  const followingEl = document.getElementById(followingElId);

  try{
    const [followersSnap, followingSnap] = await Promise.all([
      db.collection('follows').where('targetUid', '==', uid).get(),
      db.collection('follows').where('followerUid', '==', uid).get()
    ]);
    followersEl.firstChild.textContent = followersSnap.size;
    followingEl.firstChild.textContent = followingSnap.size;
  }catch(err){
    console.error('Erreur comptage abonnés:', err);
  }

  followersEl.onclick = () => openFollowList(uid, 'followers');
  followingEl.onclick = () => openFollowList(uid, 'following');
}

async function openFollowList(uid, mode){
  followListReturnView = uid === currentUser.uid ? 'profile' : 'user-profile';
  switchView('follow-list');

  document.getElementById('follow-list-title').textContent = mode === 'followers' ? 'Abonnés' : 'Abonnements';
  const content = document.getElementById('follow-list-content');
  content.innerHTML = '<p class="empty-sub" style="text-align:center;">Chargement...</p>';

  try{
    const field = mode === 'followers' ? 'targetUid' : 'followerUid';
    const otherField = mode === 'followers' ? 'followerUid' : 'targetUid';
    const snap = await db.collection('follows').where(field, '==', uid).get();

    if (snap.empty){
      content.innerHTML = '<p class="empty-sub" style="text-align:center;">Aucun résultat.</p>';
      return;
    }

    content.innerHTML = '';
    for (const doc of snap.docs){
      const otherUid = doc.data()[otherField];
      const userDoc = await db.collection('users').doc(otherUid).get();
      const u = userDoc.data() || {};
      const row = document.createElement('div');
      row.className = 'chat-row';
      row.innerHTML = `
        <img class="avatar-sm" src="${u.photoURL || defaultAvatar()}" />
        <div><div class="chat-row-name">${escapeHtml(u.username || 'Utilisateur')}</div></div>
      `;
      row.addEventListener('click', () => openUserProfile(otherUid));
      content.appendChild(row);
    }
  }catch(err){
    console.error('Erreur chargement liste:', err);
    content.innerHTML = '<p class="empty-sub" style="text-align:center;">Erreur : ' + escapeHtml(err.message) + '</p>';
  }
}

/**
 * Ouvre le profil public d'un autre utilisateur (avatar, statut, bio,
 * bouton suivre/se désabonner, et ses publications si autorisé).
 */
async function openUserProfile(uid){
  viewedProfileUid = uid;
  switchView('user-profile');

  const userDoc = await db.collection('users').doc(uid).get();
  if (!userDoc.exists) return;
  const u = userDoc.data();

  document.getElementById('up-avatar').src = u.photoURL || defaultAvatar();
  document.getElementById('up-username').textContent = u.username || '';
  document.getElementById('up-status').textContent = u.status || '';
  document.getElementById('up-bio').textContent = u.bio || '';

  document.getElementById('up-message-btn').onclick = () => openChat(uid, u.username);

  await loadFollowCounts(uid, 'up-followers-count', 'up-following-count');
  await refreshFollowButton(uid, !!u.isPrivate);
  await renderUserPosts(uid, !!u.isPrivate);
}

async function getFollowState(targetUid){
  const followDoc = await db.collection('follows').doc(`${currentUser.uid}_${targetUid}`).get();
  if (followDoc.exists) return 'following';

  const reqSnap = await db.collection('followRequests')
    .where('fromUid', '==', currentUser.uid)
    .where('toUid', '==', targetUid)
    .where('status', '==', 'pending')
    .limit(1)
    .get();
  if (!reqSnap.empty) return 'pending';

  return 'none';
}

async function refreshFollowButton(targetUid, isPrivate){
  const btn = document.getElementById('up-follow-btn');
  const state = await getFollowState(targetUid);

  if (state === 'following'){
    btn.textContent = 'Se désabonner';
    btn.onclick = () => unfollowUser(targetUid, isPrivate);
  } else if (state === 'pending'){
    btn.textContent = 'Demande envoyée';
    btn.onclick = () => cancelFollowRequest(targetUid);
  } else {
    btn.textContent = isPrivate ? "Demander à suivre" : 'Suivre';
    btn.onclick = () => followUser(targetUid, isPrivate);
  }
}

async function followUser(targetUid, isPrivate){
  if (isPrivate){
    await db.collection('followRequests').add({
      fromUid: currentUser.uid,
      fromUsername: currentUserData?.username || 'Utilisateur',
      fromPhoto: currentUserData?.photoURL || '',
      toUid: targetUid,
      status: 'pending',
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    sendNotification(targetUid, 'follow_request', {});
  } else {
    await db.collection('follows').doc(`${currentUser.uid}_${targetUid}`).set({
      followerUid: currentUser.uid,
      targetUid,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    sendNotification(targetUid, 'follow', {});
  }
  await refreshFollowButton(targetUid, isPrivate);
  await loadFollowCounts(targetUid, 'up-followers-count', 'up-following-count');
}

async function unfollowUser(targetUid, isPrivate){
  await db.collection('follows').doc(`${currentUser.uid}_${targetUid}`).delete();
  await refreshFollowButton(targetUid, isPrivate);
  await loadFollowCounts(targetUid, 'up-followers-count', 'up-following-count');
}

async function cancelFollowRequest(targetUid){
  const snap = await db.collection('followRequests')
    .where('fromUid', '==', currentUser.uid)
    .where('toUid', '==', targetUid)
    .where('status', '==', 'pending')
    .get();
  const batch = db.batch();
  snap.forEach(doc => batch.delete(doc.ref));
  await batch.commit();
  await refreshFollowButton(targetUid, true);
}

async function renderUserPosts(targetUid, isPrivate){
  const list = document.getElementById('up-posts-list');
  const notice = document.getElementById('up-private-notice');
  list.querySelectorAll('.post-card').forEach(el => el.remove());

  if (targetUid === currentUser.uid){
    notice.classList.add('hidden');
  } else if (isPrivate){
    const state = await getFollowState(targetUid);
    if (state !== 'following'){
      notice.classList.remove('hidden');
      return;
    }
  }
  notice.classList.add('hidden');

  try{
    const snap = await db.collection('posts')
      .where('uid', '==', targetUid)
      .get();
    const posts = [];
    snap.forEach(doc => posts.push({ id: doc.id, data: doc.data() }));
    posts.sort((a, b) => (b.data.createdAt?.toMillis?.() || 0) - (a.data.createdAt?.toMillis?.() || 0));
    posts.forEach(p => list.appendChild(buildPostCard(p.id, p.data)));
  }catch(err){
    console.error('Erreur chargement publications:', err);
    list.innerHTML = '<p class="empty-sub" style="text-align:center;">Erreur de chargement : ' + escapeHtml(err.message) + '</p>';
  }
}

// ---------- Demandes d'abonnement en attente (pour les comptes privés) ----------
function initFollowRequests(){
  if (followRequestsUnsubscribe) followRequestsUnsubscribe();
  followRequestsUnsubscribe = db.collection('followRequests')
    .where('toUid', '==', currentUser.uid)
    .where('status', '==', 'pending')
    .onSnapshot(renderFollowRequests, err => console.error('Erreur demandes:', err));
}

function renderFollowRequests(snap){
  const list = document.getElementById('follow-requests-list');
  list.innerHTML = '';
  if (snap.empty) return;

  const header = document.createElement('h3');
  header.className = 'view-title';
  header.textContent = "Demandes d'abonnement";
  list.appendChild(header);

  snap.forEach(doc => {
    const r = doc.data();
    const row = document.createElement('div');
    row.className = 'notification-item unread';
    row.innerHTML = `
      <img class="avatar-sm" src="${r.fromPhoto || defaultAvatar()}" />
      <span class="notif-text" style="flex:1;"><b>${escapeHtml(r.fromUsername)}</b> souhaite t'abonner</span>
      <div class="user-profile-actions" style="margin:0; gap:6px;">
        <button class="btn btn-small approve-follow-btn">Accepter</button>
        <button class="btn btn-small reject-follow-btn">Refuser</button>
      </div>
    `;
    row.querySelector('.approve-follow-btn').addEventListener('click', () => approveFollowRequest(doc.id, r.fromUid));
    row.querySelector('.reject-follow-btn').addEventListener('click', () => rejectFollowRequest(doc.id));
    list.appendChild(row);
  });
}

async function approveFollowRequest(reqId, fromUid){
  await db.collection('follows').doc(`${fromUid}_${currentUser.uid}`).set({
    followerUid: fromUid,
    targetUid: currentUser.uid,
    createdAt: firebase.firestore.FieldValue.serverTimestamp()
  });
  await db.collection('followRequests').doc(reqId).update({ status: 'approved' });
}

async function rejectFollowRequest(reqId){
  await db.collection('followRequests').doc(reqId).update({ status: 'rejected' });
}
