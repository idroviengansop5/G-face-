// ============================================================
// G-face — feed.js : fil vidéo, likes, commentaires
// ============================================================

let feedUnsubscribe = null;

function initFeed(){
  if (feedUnsubscribe) feedUnsubscribe();
  feedUnsubscribe = db.collection('posts')
    .orderBy('createdAt', 'desc')
    .limit(50)
    .onSnapshot(renderFeed, (err) => console.error('Erreur fil:', err));
}

function renderFeed(snapshot){
  const list = document.getElementById('feed-list');
  const empty = document.getElementById('feed-empty');

  if (snapshot.empty){
    list.innerHTML = '';
    list.appendChild(empty);
    return;
  }

  list.innerHTML = '';
  snapshot.forEach(doc => {
    list.appendChild(buildPostCard(doc.id, doc.data()));
  });
}

function buildPostCard(postId, post){
  const card = document.createElement('div');
  card.className = 'post-card';

  const liked = (post.likes || []).includes(currentUser.uid);
  const likeCount = (post.likes || []).length;

  card.innerHTML = `
    <div class="post-head">
      <img class="avatar-sm" src="${post.userPhoto || defaultAvatar()}" />
      <span class="post-username">${escapeHtml(post.username || 'Utilisateur')}</span>
    </div>
    <video class="post-video" src="${post.videoURL}" controls playsinline preload="metadata"></video>
    <div class="post-actions">
      <button class="action-btn like-btn ${liked ? 'liked' : ''}" data-id="${postId}">
        ${liked ? '♥' : '♡'} <span class="like-count">${likeCount}</span>
      </button>
      <button class="action-btn comment-toggle-btn" data-id="${postId}">💬 <span class="comment-count">${post.commentCount || 0}</span></button>
    </div>
    ${post.caption ? `<div class="post-caption"><b>${escapeHtml(post.username)}</b>${escapeHtml(post.caption)}</div>` : ''}
    <div class="comments-box hidden" id="comments-${postId}">
      <div class="comments-list" id="comments-list-${postId}"></div>
      <form class="comment-form" data-id="${postId}">
        <input type="text" placeholder="Ajouter un commentaire..." maxlength="200" required />
        <button type="submit">Publier</button>
      </form>
    </div>
  `;

  card.querySelector('.like-btn').addEventListener('click', () => toggleLike(postId, liked));
  card.querySelector('.comment-toggle-btn').addEventListener('click', () => toggleComments(postId));
  card.querySelector('.comment-form').addEventListener('submit', (e) => submitComment(e, postId));

  return card;
}

async function toggleLike(postId, currentlyLiked){
  const ref = db.collection('posts').doc(postId);
  const update = currentlyLiked
    ? { likes: firebase.firestore.FieldValue.arrayRemove(currentUser.uid) }
    : { likes: firebase.firestore.FieldValue.arrayUnion(currentUser.uid) };
  try{
    await ref.update(update);
  }catch(err){ console.error(err); }
}

let openComments = {};

function toggleComments(postId){
  const box = document.getElementById('comments-' + postId);
  box.classList.toggle('hidden');
  if (!box.classList.contains('hidden') && !openComments[postId]){
    openComments[postId] = true;
    db.collection('posts').doc(postId).collection('comments')
      .orderBy('createdAt', 'asc')
      .onSnapshot(snap => {
        const list = document.getElementById('comments-list-' + postId);
        if (!list) return;
        list.innerHTML = '';
        snap.forEach(d => {
          const c = d.data();
          const line = document.createElement('div');
          line.className = 'comment-line';
          line.innerHTML = `<b>${escapeHtml(c.username)}</b>${escapeHtml(c.text)}`;
          list.appendChild(line);
        });
      });
  }
}

async function submitComment(e, postId){
  e.preventDefault();
  const input = e.target.querySelector('input');
  const text = input.value.trim();
  if (!text) return;
  input.value = '';

  const postRef = db.collection('posts').doc(postId);
  await postRef.collection('comments').add({
    uid: currentUser.uid,
    username: currentUserData?.username || 'Utilisateur',
    text,
    createdAt: firebase.firestore.FieldValue.serverTimestamp()
  });
  await postRef.update({ commentCount: firebase.firestore.FieldValue.increment(1) });
}

function defaultAvatar(){
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40"><rect width="40" height="40" fill="%23262933"/></svg>`
  );
}

function escapeHtml(str){
  if (!str) return '';
  return str.replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}
