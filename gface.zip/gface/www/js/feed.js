// ============================================================
// G-face — feed.js : fil vidéo paginé, likes, commentaires (avec réponses), vues, épingle
// ============================================================

let feedListenerUnsubscribe = null;
let realtimeFeedDocs = [];
let olderFeedDocs = [];
let feedCursor = null;
let feedEndReached = false;
let loadingMoreFeed = false;
let feedMode = 'recent';
const FEED_PAGE_SIZE = 10;
const countedViews = new Set();

document.querySelectorAll('.feed-filter-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    if (btn.dataset.mode === feedMode) return;
    document.querySelectorAll('.feed-filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    feedMode = btn.dataset.mode;
    if (feedMode === 'top') loadTopPosts();
    else initFeed();
  });
});

async function loadTopPosts(){
  if (feedListenerUnsubscribe) feedListenerUnsubscribe();
  const list = document.getElementById('feed-list');
  list.innerHTML = '<p class="empty-sub" style="text-align:center;">Chargement...</p>';

  try{
    const snap = await db.collection('posts').orderBy('createdAt', 'desc').limit(200).get();
    const posts = [];
    snap.forEach(doc => { if (!blockedUids.has(doc.data().uid)) posts.push({ id: doc.id, data: doc.data() }); });
    posts.sort((a, b) => (b.data.likeCount ?? (b.data.likes || []).length) - (a.data.likeCount ?? (a.data.likes || []).length));

    const empty = document.getElementById('feed-empty');
    if (posts.length === 0){
      list.innerHTML = '';
      list.appendChild(empty);
      return;
    }
    list.innerHTML = '';
    posts.slice(0, 30).forEach(p => list.appendChild(buildPostCard(p.id, p.data)));
  }catch(err){
    list.innerHTML = '<p class="empty-sub" style="text-align:center;">Erreur : ' + escapeHtml(err.message) + '</p>';
  }
}

function initFeed(){
  if (feedListenerUnsubscribe) feedListenerUnsubscribe();
  realtimeFeedDocs = [];
  olderFeedDocs = [];
  feedCursor = null;
  feedEndReached = false;

  feedListenerUnsubscribe = db.collection('posts')
    .orderBy('createdAt', 'desc')
    .limit(FEED_PAGE_SIZE)
    .onSnapshot(snap => {
      realtimeFeedDocs = snap.docs;
      if (snap.docs.length > 0) feedCursor = snap.docs[snap.docs.length - 1];
      renderFeedCombined();
    }, (err) => {
      console.error('Erreur fil:', err);
      const list = document.getElementById('feed-list');
      list.innerHTML = '<p class="empty-sub" style="text-align:center;">Erreur de chargement : ' + escapeHtml(err.message) + '</p>';
    });

  setupFeedScrollListener();
}

function setupFeedScrollListener(){
  const feedView = document.getElementById('view-feed');
  feedView.onscroll = () => {
    if (feedView.scrollTop + feedView.clientHeight > feedView.scrollHeight - 300){
      loadMoreFeed();
    }
  };
}

async function loadMoreFeed(){
  if (loadingMoreFeed || feedEndReached || !feedCursor || feedMode !== 'recent') return;
  loadingMoreFeed = true;

  try{
    const snap = await db.collection('posts')
      .orderBy('createdAt', 'desc')
      .startAfter(feedCursor)
      .limit(FEED_PAGE_SIZE)
      .get();

    if (snap.empty){
      feedEndReached = true;
      return;
    }
    olderFeedDocs = olderFeedDocs.concat(snap.docs);
    feedCursor = snap.docs[snap.docs.length - 1];
    if (snap.docs.length < FEED_PAGE_SIZE) feedEndReached = true;
    renderFeedCombined();
  }catch(err){
    console.error('Erreur chargement suite du fil:', err);
  }finally{
    loadingMoreFeed = false;
  }
}

function renderFeedCombined(){
  const list = document.getElementById('feed-list');
  const empty = document.getElementById('feed-empty');

  const realtimeIds = new Set(realtimeFeedDocs.map(d => d.id));
  const combined = [
    ...realtimeFeedDocs,
    ...olderFeedDocs.filter(d => !realtimeIds.has(d.id))
  ].filter(d => !blockedUids.has(d.data().uid));

  if (combined.length === 0){
    list.innerHTML = '';
    list.appendChild(empty);
    return;
  }

  list.innerHTML = '';
  combined.forEach(doc => list.appendChild(buildPostCard(doc.id, doc.data())));

  if (!feedEndReached){
    const loadingMsg = document.createElement('p');
    loadingMsg.className = 'empty-sub';
    loadingMsg.style.textAlign = 'center';
    loadingMsg.textContent = 'Fais défiler pour voir plus...';
    list.appendChild(loadingMsg);
  }
}

function buildPostCard(postId, post){
  const card = document.createElement('div');
  card.className = 'post-card';

  const liked = (post.likes || []).includes(currentUser.uid);
  const likeCount = (post.likes || []).length;
  const isOwner = post.uid === currentUser.uid;
  const isBookmarked = bookmarkedPostIds.has(postId);

  card.innerHTML = `
    <div class="post-head">
      <img class="avatar-sm post-avatar-link" src="${post.userPhoto || defaultAvatar()}" />
      <span class="post-username post-avatar-link">${escapeHtml(post.username || 'Utilisateur')}</span>
      ${post.pinned ? '<span class="pinned-badge">📌 Épinglé</span>' : ''}
      ${isOwner ? `
        <button class="pin-post-btn" data-id="${postId}" title="${post.pinned ? 'Désépingler' : 'Épingler'}">${post.pinned ? '📌' : '📍'}</button>
        <button class="delete-post-btn" data-id="${postId}" title="Supprimer">🗑</button>` : ''}
    </div>
    <video class="post-video" src="${post.videoURL}" controls playsinline preload="metadata"></video>
    <div class="post-actions">
      <button class="action-btn like-btn ${liked ? 'liked' : ''}" data-id="${postId}">${liked ? '♥' : '♡'}</button>
      <span class="like-count-link" data-id="${postId}">${likeCount}</span>
      <button class="action-btn comment-toggle-btn" data-id="${postId}">💬 <span class="comment-count">${post.commentCount || 0}</span></button>
      <button class="action-btn share-btn" data-id="${postId}">↗ Partager</button>
      <button class="action-btn bookmark-btn ${isBookmarked ? 'liked' : ''}" data-id="${postId}">${isBookmarked ? '🔖' : '📑'}</button>
      <span class="view-count">👁 <span class="view-count-value">${post.views || 0}</span></span>
      ${!isOwner ? `<button class="post-report-btn" data-id="${postId}" title="Signaler">⚑</button>` : ''}
    </div>
    ${post.caption ? `<div class="post-caption"><b>${escapeHtml(post.username)}</b>${renderCaptionWithHashtags(post.caption)}</div>` : ''}
    <div class="comments-box hidden" id="comments-${postId}">
      <div class="comments-list" id="comments-list-${postId}"></div>
      <form class="comment-form" data-id="${postId}">
        <input type="text" placeholder="Ajouter un commentaire..." maxlength="200" required />
        <button type="submit">Publier</button>
      </form>
    </div>
  `;

  card.querySelectorAll('.post-avatar-link').forEach(el => {
    el.style.cursor = 'pointer';
    el.addEventListener('click', () => { if (post.uid) openUserProfile(post.uid); });
  });

  card.querySelectorAll('.hashtag-link').forEach(el => {
    el.addEventListener('click', () => goToHashtag(el.dataset.tag));
  });

  card.querySelector('.like-btn').addEventListener('click', () => toggleLike(postId, liked, post.uid));
  card.querySelector('.like-count-link').addEventListener('click', () => openLikesList(post.likes || []));
  card.querySelector('.comment-toggle-btn').addEventListener('click', () => toggleComments(postId));
  card.querySelector('.comment-form').addEventListener('submit', (e) => submitComment(e, postId, post.uid));
  card.querySelector('.share-btn').addEventListener('click', () => sharePost(post));
  card.querySelector('.bookmark-btn').addEventListener('click', () => toggleBookmark(postId));
  if (isOwner){
    card.querySelector('.delete-post-btn').addEventListener('click', () => deletePost(postId));
    card.querySelector('.pin-post-btn').addEventListener('click', () => togglePin(postId, !!post.pinned));
  } else {
    card.querySelector('.post-report-btn').addEventListener('click', () => reportContent('post', postId, post.uid));
  }

  const videoEl = card.querySelector('.post-video');
  videoEl.addEventListener('play', () => registerView(postId), { once: true });

  return card;
}

async function togglePin(postId, currentlyPinned){
  try{
    if (currentlyPinned){
      await db.collection('posts').doc(postId).update({ pinned: false });
      return;
    }
    // Désépingle toute autre publication déjà épinglée par cet utilisateur
    const snap = await db.collection('posts').where('uid', '==', currentUser.uid).get();
    const batch = db.batch();
    snap.forEach(doc => {
      if (doc.data().pinned) batch.update(doc.ref, { pinned: false });
    });
    batch.update(db.collection('posts').doc(postId), { pinned: true });
    await batch.commit();
  }catch(err){
    alert("Échec de l'épinglage : " + err.message);
  }
}

function registerView(postId){
  if (countedViews.has(postId)) return;
  countedViews.add(postId);
  db.collection('posts').doc(postId).update({
    views: firebase.firestore.FieldValue.increment(1)
  }).catch(err => console.error('Erreur comptage vue:', err));
}

async function sharePost(post){
  const shareData = {
    title: 'G-face',
    text: `Regarde la publication de ${post.username} sur G-face !`,
    url: post.videoURL
  };
  try{
    if (navigator.share){
      await navigator.share(shareData);
    } else {
      await navigator.clipboard.writeText(post.videoURL);
      alert('Lien de la vidéo copié dans le presse-papiers !');
    }
  }catch(err){
    if (err.name !== 'AbortError') console.error('Erreur partage:', err);
  }
}

async function toggleLike(postId, currentlyLiked, postOwnerUid){
  const ref = db.collection('posts').doc(postId);
  const update = currentlyLiked
    ? { likes: firebase.firestore.FieldValue.arrayRemove(currentUser.uid), likeCount: firebase.firestore.FieldValue.increment(-1) }
    : { likes: firebase.firestore.FieldValue.arrayUnion(currentUser.uid), likeCount: firebase.firestore.FieldValue.increment(1) };
  try{
    await ref.update(update);
    if (!currentlyLiked){
      sendNotification(postOwnerUid, 'like', { postId });
    }
  }catch(err){ console.error(err); }
}

async function deletePost(postId){
  if (!confirm('Supprimer définitivement cette publication ?')) return;
  try{
    await db.collection('posts').doc(postId).delete();
  }catch(err){
    alert('Échec de la suppression : ' + err.message);
  }
}

let openComments = {};

function toggleComments(postId){
  const box = document.getElementById('comments-' + postId);
  box.classList.toggle('hidden');
  if (!box.classList.contains('hidden') && !openComments[postId]){
    openComments[postId] = true;
    db.collection('posts').doc(postId).collection('comments')
      .orderBy('createdAt', 'asc')
      .onSnapshot(snap => {
        const list = document.getElementById('comments-list-' + postId);
        if (!list) return;

        const all = [];
        snap.forEach(d => all.push({ id: d.id, ...d.data() }));
        const topLevel = all.filter(c => !c.replyTo);
        const repliesByParent = {};
        all.filter(c => c.replyTo).forEach(c => {
          (repliesByParent[c.replyTo] = repliesByParent[c.replyTo] || []).push(c);
        });

        list.innerHTML = '';
        topLevel.forEach(c => {
          list.appendChild(buildCommentLine(postId, c, false));
          (repliesByParent[c.id] || []).forEach(r => {
            list.appendChild(buildCommentLine(postId, r, true));
          });
        });
      });
  }
}

function buildCommentLine(postId, c, isReply){
  const isOwnComment = c.uid === currentUser.uid;
  const line = document.createElement('div');
  line.className = 'comment-line' + (isReply ? ' reply-line' : '');
  line.innerHTML = `
    <span class="comment-text">
      <b>${escapeHtml(c.username)}</b><span class="comment-text-value">${escapeHtml(filterProfanity(c.text))}</span>
      ${!isReply ? '<button class="reply-btn">Répondre</button>' : ''}
    </span>
    ${isOwnComment ? `
      <span class="comment-own-actions">
        <button class="edit-comment-btn">✎</button>
        <button class="delete-comment-btn">🗑</button>
      </span>` : ''}
  `;
  if (isOwnComment){
    line.querySelector('.edit-comment-btn').addEventListener('click', () => editComment(postId, c.id, c.text));
    line.querySelector('.delete-comment-btn').addEventListener('click', () => deleteComment(postId, c.id));
  }
  if (!isReply){
    line.querySelector('.reply-btn').addEventListener('click', () => toggleReplyForm(postId, c.id, line));
  }
  return line;
}

function toggleReplyForm(postId, parentCommentId, afterEl){
  const existing = afterEl.nextElementSibling;
  if (existing && existing.classList.contains('reply-form-wrap')){
    existing.remove();
    return;
  }
  const wrap = document.createElement('form');
  wrap.className = 'reply-form reply-form-wrap';
  wrap.innerHTML = `<input type="text" placeholder="Répondre..." maxlength="200" required /><button type="submit">Envoyer</button>`;
  wrap.addEventListener('submit', (e) => {
    e.preventDefault();
    const input = wrap.querySelector('input');
    const text = input.value.trim();
    if (!text) return;
    submitReply(postId, parentCommentId, text);
    wrap.remove();
  });
  afterEl.insertAdjacentElement('afterend', wrap);
  wrap.querySelector('input').focus();
}

async function submitReply(postId, parentCommentId, text){
  const postRef = db.collection('posts').doc(postId);
  await postRef.collection('comments').add({
    uid: currentUser.uid,
    username: currentUserData?.username || 'Utilisateur',
    text,
    replyTo: parentCommentId,
    createdAt: firebase.firestore.FieldValue.serverTimestamp()
  });
  await postRef.update({ commentCount: firebase.firestore.FieldValue.increment(1) });
}

async function editComment(postId, commentId, currentText){
  const newText = prompt('Modifier ton commentaire :', currentText);
  if (newText === null) return;
  const trimmed = newText.trim();
  if (!trimmed) return;
  try{
    await db.collection('posts').doc(postId).collection('comments').doc(commentId).update({ text: trimmed });
  }catch(err){
    alert('Échec de la modification : ' + err.message);
  }
}

async function deleteComment(postId, commentId){
  if (!confirm('Supprimer ce commentaire ?')) return;
  try{
    await db.collection('posts').doc(postId).collection('comments').doc(commentId).delete();
    await db.collection('posts').doc(postId).update({ commentCount: firebase.firestore.FieldValue.increment(-1) });
  }catch(err){
    alert('Échec de la suppression : ' + err.message);
  }
}

async function submitComment(e, postId, postOwnerUid){
  e.preventDefault();
  const input = e.target.querySelector('input');
  const text = input.value.trim();
  if (!text) return;
  input.value = '';

  const postRef = db.collection('posts').doc(postId);
  await postRef.collection('comments').add({
    uid: currentUser.uid,
    username: currentUserData?.username || 'Utilisateur',
    text,
    createdAt: firebase.firestore.FieldValue.serverTimestamp()
  });
  await postRef.update({ commentCount: firebase.firestore.FieldValue.increment(1) });
  sendNotification(postOwnerUid, 'comment', { postId, text });
}

function defaultAvatar(){
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40"><rect width="40" height="40" fill="%23262933"/></svg>`
  );
}

function escapeHtml(str){
  if (!str) return '';
  return str.replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

function renderCaptionWithHashtags(caption){
  const escaped = escapeHtml(caption);
  return escaped.replace(/#(\w+)/g, (match, word) => {
    return `<span class="hashtag-link" data-tag="${word}">#${word}</span>`;
  });
}

function goToHashtag(tag){
  openHashtagPage(tag);
}
