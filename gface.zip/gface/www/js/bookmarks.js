// ============================================================
// G-face — bookmarks.js : favoris + liste des personnes qui ont aimé
// ============================================================

let bookmarkedPostIds = new Set();
let bookmarksUnsubscribe = null;

function initBookmarks(){
  if (bookmarksUnsubscribe) bookmarksUnsubscribe();
  bookmarksUnsubscribe = db.collection('bookmarks')
    .where('uid', '==', currentUser.uid)
    .onSnapshot(snap => {
      bookmarkedPostIds = new Set();
      snap.forEach(doc => bookmarkedPostIds.add(doc.data().postId));
    }, err => console.error('Erreur favoris:', err));
}

async function toggleBookmark(postId){
  const id = `${currentUser.uid}_${postId}`;
  try{
    if (bookmarkedPostIds.has(postId)){
      await db.collection('bookmarks').doc(id).delete();
    } else {
      await db.collection('bookmarks').doc(id).set({
        uid: currentUser.uid,
        postId,
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
      });
    }
  }catch(err){
    alert('Échec : ' + err.message);
  }
}

document.getElementById('bookmarks-nav-btn').addEventListener('click', openBookmarksView);
document.getElementById('bookmarks-back-btn').addEventListener('click', () => switchView('profile'));

async function openBookmarksView(){
  switchView('bookmarks');
  const list = document.getElementById('bookmarks-list');
  list.innerHTML = '<p class="empty-sub" style="text-align:center;">Chargement...</p>';

  try{
    const snap = await db.collection('bookmarks').where('uid', '==', currentUser.uid).get();
    if (snap.empty){
      list.innerHTML = '<p class="empty-sub" style="text-align:center;">Aucun favori pour l\'instant.</p>';
      return;
    }

    const postDocs = await Promise.all(
      snap.docs.map(doc => db.collection('posts').doc(doc.data().postId).get())
    );

    list.innerHTML = '';
    let count = 0;
    postDocs.forEach(pd => {
      if (pd.exists){
        list.appendChild(buildPostCard(pd.id, pd.data()));
        count++;
      }
    });
    if (count === 0){
      list.innerHTML = '<p class="empty-sub" style="text-align:center;">Aucun favori pour l\'instant.</p>';
    }
  }catch(err){
    list.innerHTML = '<p class="empty-sub" style="text-align:center;">Erreur : ' + escapeHtml(err.message) + '</p>';
  }
}

// ---------- Liste des personnes ayant aimé une publication ----------
document.getElementById('likes-list-back-btn').addEventListener('click', () => switchView('feed'));

async function openLikesList(likeUids){
  switchView('likes-list');
  const list = document.getElementById('likes-list-content');
  list.innerHTML = '';

  if (!likeUids || likeUids.length === 0){
    list.innerHTML = '<p class="empty-sub" style="text-align:center;">Personne n\'a encore aimé cette publication.</p>';
    return;
  }

  list.innerHTML = '<p class="empty-sub" style="text-align:center;">Chargement...</p>';
  try{
    const userDocs = await Promise.all(likeUids.map(uid => db.collection('users').doc(uid).get()));
    list.innerHTML = '';
    userDocs.forEach(doc => {
      if (!doc.exists) return;
      const u = doc.data();
      const row = document.createElement('div');
      row.className = 'chat-row';
      row.innerHTML = `
        <img class="avatar-sm" src="${u.photoURL || defaultAvatar()}" />
        <div><div class="chat-row-name">${escapeHtml(u.username || 'Utilisateur')}</div></div>
      `;
      row.addEventListener('click', () => openUserProfile(doc.id));
      list.appendChild(row);
    });
  }catch(err){
    list.innerHTML = '<p class="empty-sub" style="text-align:center;">Erreur : ' + escapeHtml(err.message) + '</p>';
  }
}
