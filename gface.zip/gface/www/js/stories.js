// ============================================================
// G-face — stories.js : stories éphémères (visibles 24h)
// ============================================================

const STORY_LIFETIME_MS = 24 * 60 * 60 * 1000;
let storiesUnsubscribe = null;
let hasOwnActiveStory = false;

function initStories(){
  document.getElementById('my-story-avatar').src = currentUserData?.photoURL || defaultAvatar();

  // Appuyer sur ton propre avatar : voir ta story si tu en as une, sinon en ajouter une
  document.getElementById('my-story-avatar').addEventListener('click', () => {
    if (hasOwnActiveStory){
      openStoryViewer(currentUser.uid);
    } else {
      document.getElementById('story-file-input').click();
    }
  });

  // Le bouton "+" ajoute toujours une nouvelle story
  document.getElementById('story-add-btn').querySelector('.story-plus').addEventListener('click', (e) => {
    e.stopPropagation();
    document.getElementById('story-file-input').click();
  });

  document.getElementById('story-file-input').addEventListener('change', handleStoryUpload);

  if (storiesUnsubscribe) storiesUnsubscribe();
  const cutoff = new Date(Date.now() - STORY_LIFETIME_MS);
  storiesUnsubscribe = db.collection('stories')
    .where('createdAt', '>=', cutoff)
    .orderBy('createdAt', 'desc')
    .onSnapshot(renderStoriesBar, err => console.error('Erreur stories:', err));
}

async function handleStoryUpload(e){
  const file = e.target.files[0];
  if (!file) return;
  e.target.value = '';

  if (file.size > 30 * 1024 * 1024){
    alert('Fichier trop lourd pour une story (limite : 30 Mo).');
    return;
  }

  const isVideo = file.type.startsWith('video/');
  const addBtn = document.getElementById('story-add-btn');
  addBtn.style.opacity = '0.5';

  try{
    const mediaURL = await uploadToCloudinary(file, isVideo ? 'video' : 'image');
    await db.collection('stories').add({
      uid: currentUser.uid,
      username: currentUserData?.username || 'Utilisateur',
      userPhoto: currentUserData?.photoURL || '',
      mediaURL,
      mediaType: isVideo ? 'video' : 'image',
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
  }catch(err){
    alert("Échec de l'envoi de la story : " + err.message);
  }finally{
    addBtn.style.opacity = '1';
  }
}

function renderStoriesBar(snap){
  const list = document.getElementById('stories-list');
  list.innerHTML = '';

  // Ne garder qu'une story par utilisateur (la plus récente)
  const seen = new Set();
  const byOtherUsers = [];
  hasOwnActiveStory = false;

  snap.forEach(doc => {
    const s = doc.data();
    if (s.uid === currentUser.uid){
      hasOwnActiveStory = true;
      return;
    }
    if (seen.has(s.uid)) return;
    seen.add(s.uid);
    byOtherUsers.push({ id: doc.id, ...s });
  });

  // Anneau coloré autour de "Ta story" si tu as une story active
  const myRing = document.querySelector('#story-add-btn .story-avatar-ring');
  myRing.classList.toggle('add-ring', !hasOwnActiveStory);

  byOtherUsers.forEach(story => {
    const bubble = document.createElement('div');
    bubble.className = 'story-bubble';
    bubble.innerHTML = `
      <div class="story-avatar-ring">
        <img class="story-avatar" src="${story.userPhoto || defaultAvatar()}" />
      </div>
      <span class="story-label">${escapeHtml(story.username)}</span>
    `;
    bubble.addEventListener('click', () => openStoryViewer(story.uid));
    list.appendChild(bubble);
  });
}

async function openStoryViewer(uid){
  try{
    const snap = await db.collection('stories').where('uid', '==', uid).get();

    const cutoffMs = Date.now() - STORY_LIFETIME_MS;
    const stories = [];
    snap.forEach(doc => {
      const s = doc.data();
      const ts = s.createdAt?.toMillis ? s.createdAt.toMillis() : 0;
      if (ts >= cutoffMs) stories.push(s);
    });
    stories.sort((a, b) => (a.createdAt?.toMillis?.() || 0) - (b.createdAt?.toMillis?.() || 0));

    if (stories.length === 0){
      alert("Cette story n'est plus disponible (elle a peut-être expiré après 24h).");
      return;
    }

    showStoryOverlay(stories, 0);
  }catch(err){
    console.error('Erreur ouverture story:', err);
    alert("Impossible d'ouvrir la story : " + err.message);
  }
}

function showStoryOverlay(stories, index){
  let overlay = document.getElementById('story-overlay');
  if (overlay) overlay.remove();

  const story = stories[index];
  overlay = document.createElement('div');
  overlay.id = 'story-overlay';
  overlay.className = 'story-overlay';

  const mediaTag = story.mediaType === 'video'
    ? `<video src="${story.mediaURL}" class="story-media" autoplay playsinline></video>`
    : `<img src="${story.mediaURL}" class="story-media" />`;

  overlay.innerHTML = `
    <div class="story-overlay-header">
      <img class="avatar-sm" src="${story.userPhoto || defaultAvatar()}" />
      <span class="post-username">${escapeHtml(story.username)}</span>
      <button class="story-close-btn">✕</button>
    </div>
    ${mediaTag}
    <div class="story-tap-zone story-tap-prev"></div>
    <div class="story-tap-zone story-tap-next"></div>
  `;

  document.body.appendChild(overlay);

  overlay.querySelector('.story-close-btn').addEventListener('click', () => overlay.remove());
  overlay.querySelector('.story-tap-next').addEventListener('click', () => {
    if (index < stories.length - 1) showStoryOverlay(stories, index + 1);
    else overlay.remove();
  });
  overlay.querySelector('.story-tap-prev').addEventListener('click', () => {
    if (index > 0) showStoryOverlay(stories, index - 1);
  });

  // Avance automatiquement après 6 secondes pour les images
  if (story.mediaType === 'image'){
    setTimeout(() => {
      if (document.getElementById('story-overlay') === overlay){
        if (index < stories.length - 1) showStoryOverlay(stories, index + 1);
        else overlay.remove();
      }
    }, 6000);
  }
}
