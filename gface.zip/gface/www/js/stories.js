// ============================================================
// G-face — stories.js : stories éphémères (24h) — caméra, galerie,
// texte+voix, légende, son enregistré, like, réponse, suppression, vues
// ============================================================

const STORY_LIFETIME_MS = 24 * 60 * 60 * 1000;
let storiesUnsubscribe = null;
let hasOwnActiveStory = false;

// État de la composition en cours
let composeSelectedFile = null;   // fichier image/vidéo choisi (caméra ou galerie)
let composeMediaType = null;      // 'image' | 'video'
let composeAudioBlob = null;      // son enregistré (remplace/ajoute au son original)
let mediaRecorder = null;
let recordedChunks = [];
const STORY_BG_COLORS = ['#0E3B32', '#E8A33D', '#2C2A73', '#7A1E3A', '#1D1F26'];
let textStoryBgIndex = 0;

function initStories(){
  document.getElementById('my-story-avatar').src = currentUserData?.photoURL || defaultAvatar();

  document.getElementById('my-story-avatar').addEventListener('click', () => {
    if (hasOwnActiveStory){
      openStoryViewer(currentUser.uid);
    } else {
      showStoryOptionsSheet();
    }
  });

  document.getElementById('story-add-btn').querySelector('.story-plus').addEventListener('click', (e) => {
    e.stopPropagation();
    showStoryOptionsSheet();
  });

  document.getElementById('story-camera-input').addEventListener('change', (e) => onMediaChosen(e, 'camera'));
  document.getElementById('story-gallery-input').addEventListener('change', (e) => onMediaChosen(e, 'gallery'));

  if (storiesUnsubscribe) storiesUnsubscribe();
  const cutoff = new Date(Date.now() - STORY_LIFETIME_MS);
  storiesUnsubscribe = db.collection('stories')
    .where('createdAt', '>=', cutoff)
    .orderBy('createdAt', 'desc')
    .onSnapshot(renderStoriesBar, err => console.error('Erreur stories:', err));
}

// ============================================================
// Choix du mode de création (caméra / galerie / texte+voix)
// ============================================================
function showStoryOptionsSheet(){
  const overlay = document.createElement('div');
  overlay.className = 'story-viewers-overlay';
  overlay.innerHTML = `
    <div class="story-viewers-sheet">
      <h3 class="view-title">Nouvelle story</h3>
      <button class="btn btn-small story-option-btn" style="width:100%; margin-bottom:8px;" id="opt-camera">📷 Prendre une photo/vidéo</button>
      <button class="btn btn-small story-option-btn" style="width:100%; margin-bottom:8px;" id="opt-gallery">🖼 Depuis la galerie</button>
      <button class="btn btn-small story-option-btn" style="width:100%;" id="opt-text">✏️ Texte + voix</button>
    </div>
  `;
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);

  overlay.querySelector('#opt-camera').addEventListener('click', () => {
    overlay.remove();
    document.getElementById('story-camera-input').click();
  });
  overlay.querySelector('#opt-gallery').addEventListener('click', () => {
    overlay.remove();
    document.getElementById('story-gallery-input').click();
  });
  overlay.querySelector('#opt-text').addEventListener('click', () => {
    overlay.remove();
    openTextStoryCompose();
  });
}

function onMediaChosen(e, source){
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;

  if (file.size > 30 * 1024 * 1024){
    alert('Fichier trop lourd pour une story (limite : 30 Mo).');
    return;
  }

  composeSelectedFile = file;
  composeMediaType = file.type.startsWith('video/') ? 'video' : 'image';
  composeAudioBlob = null;
  openMediaCompose();
}

// ============================================================
// Compose : story à partir d'une photo/vidéo (caméra ou galerie)
// ============================================================
function openMediaCompose(){
  const overlay = document.createElement('div');
  overlay.id = 'story-compose-overlay';
  overlay.className = 'story-overlay';

  const previewURL = URL.createObjectURL(composeSelectedFile);
  const mediaTag = composeMediaType === 'video'
    ? `<video src="${previewURL}" class="story-media" muted="${composeAudioBlob ? 'true' : 'false'}" autoplay loop playsinline></video>`
    : `<img src="${previewURL}" class="story-media" />`;

  overlay.innerHTML = `
    <div class="story-overlay-header">
      <button class="story-close-btn" id="compose-cancel-btn">✕</button>
    </div>
    ${mediaTag}
    <div class="story-compose-bar">
      <div class="caption-with-mic">
        <input type="text" id="story-caption-input" class="story-caption-input" placeholder="Ajouter une légende..." maxlength="150" />
        <button type="button" class="mic-btn" id="story-caption-mic-btn">🎤</button>
      </div>
      <button class="btn btn-small" id="record-audio-btn">🎤 Ajouter un son</button>
      <span id="audio-status" class="empty-sub"></span>
      <button class="btn btn-primary" id="publish-story-btn" style="width:100%; margin-top:10px;">Publier la story</button>
    </div>
  `;
  document.body.appendChild(overlay);

  overlay.querySelector('#compose-cancel-btn').addEventListener('click', () => {
    composeSelectedFile = null; composeAudioBlob = null;
    overlay.remove();
  });
  overlay.querySelector('#story-caption-mic-btn').addEventListener('click', (e) => {
    startDictation((text) => {
      const input = document.getElementById('story-caption-input');
      input.value = (input.value ? input.value + ' ' : '') + text;
    }, e.currentTarget);
  });
  overlay.querySelector('#record-audio-btn').addEventListener('click', () => toggleAudioRecording(overlay, true));
  overlay.querySelector('#publish-story-btn').addEventListener('click', () => publishMediaStory(overlay));
}

// ============================================================
// Compose : story texte + voix (fond coloré avec texte)
// ============================================================
function openTextStoryCompose(){
  composeAudioBlob = null;
  textStoryBgIndex = 0;

  const overlay = document.createElement('div');
  overlay.id = 'story-compose-overlay';
  overlay.className = 'story-overlay';
  overlay.innerHTML = `
    <div class="story-overlay-header">
      <button class="story-close-btn" id="compose-cancel-btn">✕</button>
    </div>
    <div class="text-story-canvas" id="text-story-canvas" style="background:${STORY_BG_COLORS[0]};">
      <textarea id="text-story-input" class="text-story-textarea" placeholder="Écris ton texte..." maxlength="200"></textarea>
    </div>
    <div class="story-compose-bar">
      <button class="btn btn-small" id="cycle-color-btn">🎨 Changer la couleur</button>
      <button class="btn btn-small" id="dictate-text-btn">🎤 Dicter le texte</button>
      <button class="btn btn-small" id="record-audio-btn">🎤 Enregistrer un vocal</button>
      <span id="audio-status" class="empty-sub"></span>
      <button class="btn btn-primary" id="publish-story-btn" style="width:100%; margin-top:10px;">Publier la story</button>
    </div>
  `;
  document.body.appendChild(overlay);

  overlay.querySelector('#compose-cancel-btn').addEventListener('click', () => {
    composeAudioBlob = null;
    overlay.remove();
  });
  overlay.querySelector('#cycle-color-btn').addEventListener('click', () => {
    textStoryBgIndex = (textStoryBgIndex + 1) % STORY_BG_COLORS.length;
    document.getElementById('text-story-canvas').style.background = STORY_BG_COLORS[textStoryBgIndex];
  });
  overlay.querySelector('#dictate-text-btn').addEventListener('click', (e) => {
    startDictation((text) => {
      const textarea = document.getElementById('text-story-input');
      textarea.value = (textarea.value ? textarea.value + ' ' : '') + text;
    }, e.currentTarget);
  });
  overlay.querySelector('#record-audio-btn').addEventListener('click', () => toggleAudioRecording(overlay, false));
  overlay.querySelector('#publish-story-btn').addEventListener('click', () => publishTextStory(overlay));
}

// ============================================================
// Enregistrement vocal (remplace/ajoute un son à la story)
// ============================================================
async function toggleAudioRecording(overlay, isMediaMode){
  const btn = overlay.querySelector('#record-audio-btn');
  const status = overlay.querySelector('#audio-status');

  if (mediaRecorder && mediaRecorder.state === 'recording'){
    mediaRecorder.stop();
    btn.textContent = isMediaMode ? '🎤 Ajouter un son' : '🎤 Enregistrer un vocal';
    return;
  }

  try{
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    recordedChunks = [];
    mediaRecorder = new MediaRecorder(stream);
    mediaRecorder.ondataavailable = (e) => { if (e.data.size > 0) recordedChunks.push(e.data); };
    mediaRecorder.onstop = () => {
      composeAudioBlob = new Blob(recordedChunks, { type: 'audio/webm' });
      status.textContent = '🔊 Son enregistré ✓';
      stream.getTracks().forEach(t => t.stop());
      // Coupe le son original de la vidéo puisqu'un son personnalisé la remplace
      const videoEl = overlay.querySelector('video.story-media');
      if (videoEl) videoEl.muted = true;
    };
    mediaRecorder.start();
    btn.textContent = '⏹ Arrêter l\'enregistrement';
    status.textContent = 'Enregistrement en cours...';
  }catch(err){
    alert("Impossible d'accéder au micro : " + err.message);
  }
}

// ============================================================
// Publication
// ============================================================
async function publishMediaStory(overlay){
  const publishBtn = overlay.querySelector('#publish-story-btn');
  const caption = overlay.querySelector('#story-caption-input').value.trim();
  publishBtn.disabled = true;
  publishBtn.textContent = 'Publication...';

  try{
    const mediaURL = await uploadToCloudinary(composeSelectedFile, composeMediaType);
    let audioURL = null;
    if (composeAudioBlob){
      audioURL = await uploadToCloudinary(composeAudioBlob, 'video');
    }

    await db.collection('stories').add({
      uid: currentUser.uid,
      username: currentUserData?.username || 'Utilisateur',
      userPhoto: currentUserData?.photoURL || '',
      mediaURL,
      mediaType: composeMediaType,
      caption: caption || null,
      audioURL,
      likes: [],
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    composeSelectedFile = null; composeAudioBlob = null;
    overlay.remove();
  }catch(err){
    alert("Échec de la publication : " + err.message);
    publishBtn.disabled = false;
    publishBtn.textContent = 'Publier la story';
  }
}

async function publishTextStory(overlay){
  const publishBtn = overlay.querySelector('#publish-story-btn');
  const text = overlay.querySelector('#text-story-input').value.trim();
  if (!text){ alert('Écris un texte pour ta story.'); return; }

  publishBtn.disabled = true;
  publishBtn.textContent = 'Publication...';

  try{
    const blob = await renderTextToImageBlob(text, STORY_BG_COLORS[textStoryBgIndex]);
    const mediaURL = await uploadToCloudinary(blob, 'image');
    let audioURL = null;
    if (composeAudioBlob){
      audioURL = await uploadToCloudinary(composeAudioBlob, 'video');
    }

    await db.collection('stories').add({
      uid: currentUser.uid,
      username: currentUserData?.username || 'Utilisateur',
      userPhoto: currentUserData?.photoURL || '',
      mediaURL,
      mediaType: 'image',
      caption: null,
      audioURL,
      likes: [],
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    composeAudioBlob = null;
    overlay.remove();
  }catch(err){
    alert("Échec de la publication : " + err.message);
    publishBtn.disabled = false;
    publishBtn.textContent = 'Publier la story';
  }
}

function renderTextToImageBlob(text, bgColor){
  return new Promise((resolve) => {
    const canvas = document.createElement('canvas');
    canvas.width = 720; canvas.height = 1280;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 52px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    // Découpe le texte en plusieurs lignes pour qu'il tienne dans le cadre
    const words = text.split(' ');
    const lines = [];
    let currentLine = '';
    words.forEach(word => {
      const testLine = currentLine ? currentLine + ' ' + word : word;
      if (ctx.measureText(testLine).width > canvas.width - 80 && currentLine){
        lines.push(currentLine);
        currentLine = word;
      } else {
        currentLine = testLine;
      }
    });
    if (currentLine) lines.push(currentLine);

    const lineHeight = 64;
    const startY = canvas.height / 2 - ((lines.length - 1) * lineHeight) / 2;
    lines.forEach((line, i) => ctx.fillText(line, canvas.width / 2, startY + i * lineHeight));

    canvas.toBlob(blob => resolve(blob), 'image/png');
  });
}

// ============================================================
// Barre de stories (fil)
// ============================================================
function renderStoriesBar(snap){
  const list = document.getElementById('stories-list');
  list.innerHTML = '';

  const seen = new Set();
  const byOtherUsers = [];
  hasOwnActiveStory = false;

  snap.forEach(doc => {
    const s = doc.data();
    if (s.uid === currentUser.uid){
      hasOwnActiveStory = true;
      return;
    }
    if (blockedUids.has(s.uid)) return;
    if (seen.has(s.uid)) return;
    seen.add(s.uid);
    byOtherUsers.push({ id: doc.id, ...s });
  });

  const myRing = document.querySelector('#story-add-btn .story-avatar-ring');
  myRing.classList.toggle('add-ring', !hasOwnActiveStory);

  byOtherUsers.forEach(story => {
    const bubble = document.createElement('div');
    bubble.className = 'story-bubble';
    bubble.innerHTML = `
      <div class="story-avatar-ring">
        <img class="story-avatar" src="${story.userPhoto || defaultAvatar()}" />
      </div>
      <span class="story-label">${escapeHtml(story.username)}</span>
    `;
    bubble.addEventListener('click', () => openStoryViewer(story.uid));
    list.appendChild(bubble);
  });
}

async function openStoryViewer(uid){
  try{
    const snap = await db.collection('stories').where('uid', '==', uid).get();

    const cutoffMs = Date.now() - STORY_LIFETIME_MS;
    const stories = [];
    snap.forEach(doc => {
      const s = doc.data();
      const ts = s.createdAt?.toMillis ? s.createdAt.toMillis() : 0;
      if (ts >= cutoffMs) stories.push({ id: doc.id, ...s });
    });
    stories.sort((a, b) => (a.createdAt?.toMillis?.() || 0) - (b.createdAt?.toMillis?.() || 0));

    if (stories.length === 0){
      alert("Cette story n'est plus disponible (elle a peut-être expiré après 24h).");
      return;
    }

    showStoryOverlay(stories, 0);
  }catch(err){
    console.error('Erreur ouverture story:', err);
    alert("Impossible d'ouvrir la story : " + err.message);
  }
}

function registerStoryView(story){
  if (story.uid === currentUser.uid) return;
  db.collection('stories').doc(story.id).collection('views').doc(currentUser.uid).set({
    viewerUid: currentUser.uid,
    viewerUsername: currentUserData?.username || 'Utilisateur',
    viewerPhoto: currentUserData?.photoURL || '',
    viewedAt: firebase.firestore.FieldValue.serverTimestamp()
  }).catch(err => console.error('Erreur enregistrement vue story:', err));
}

async function openStoryViewersList(storyId){
  const overlay = document.createElement('div');
  overlay.className = 'story-viewers-overlay';
  overlay.innerHTML = `<div class="story-viewers-sheet"><p class="empty-sub" style="text-align:center;">Chargement...</p></div>`;
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);

  try{
    const snap = await db.collection('stories').doc(storyId).collection('views')
      .orderBy('viewedAt', 'desc').get();
    const sheet = overlay.querySelector('.story-viewers-sheet');

    if (snap.empty){
      sheet.innerHTML = '<p class="empty-sub" style="text-align:center;">Personne n\'a encore vu cette story.</p>';
      return;
    }

    sheet.innerHTML = `<h3 class="view-title">${snap.size} vue${snap.size > 1 ? 's' : ''}</h3>`;
    snap.forEach(doc => {
      const v = doc.data();
      const row = document.createElement('div');
      row.className = 'user-result-row';
      row.innerHTML = `<img class="avatar-sm" src="${v.viewerPhoto || defaultAvatar()}" /><span>${escapeHtml(v.viewerUsername)}</span>`;
      sheet.appendChild(row);
    });
  }catch(err){
    overlay.querySelector('.story-viewers-sheet').innerHTML =
      '<p class="empty-sub" style="text-align:center;">Erreur : ' + escapeHtml(err.message) + '</p>';
  }
}

async function deleteStory(storyId, overlay){
  if (!confirm('Supprimer définitivement cette story ?')) return;
  try{
    await db.collection('stories').doc(storyId).delete();
    overlay.remove();
  }catch(err){
    alert('Échec de la suppression : ' + err.message);
  }
}

async function toggleStoryLike(storyId, currentlyLiked, ownerUid, likeBtn){
  const ref = db.collection('stories').doc(storyId);
  const update = currentlyLiked
    ? { likes: firebase.firestore.FieldValue.arrayRemove(currentUser.uid) }
    : { likes: firebase.firestore.FieldValue.arrayUnion(currentUser.uid) };
  try{
    await ref.update(update);
    likeBtn.textContent = currentlyLiked ? '♡' : '♥';
    likeBtn.classList.toggle('liked', !currentlyLiked);
    likeBtn.dataset.liked = (!currentlyLiked).toString();
    if (!currentlyLiked) sendNotification(ownerUid, 'story_like', {});
  }catch(err){ console.error(err); }
}

async function sendStoryReply(story, text){
  openChat(story.uid, story.username);
  const chatRef = db.collection('chats').doc(currentChatId);
  const replyText = `↩️ Story : ${text}`;

  await chatRef.set({
    participants: [currentUser.uid, story.uid],
    lastMessage: replyText,
    lastMessageAt: firebase.firestore.FieldValue.serverTimestamp(),
    lastSenderId: currentUser.uid
  }, { merge: true });

  await chatRef.collection('messages').add({
    senderId: currentUser.uid,
    text: replyText,
    createdAt: firebase.firestore.FieldValue.serverTimestamp()
  });

  sendNotification(story.uid, 'message', {});
}

function showStoryOverlay(stories, index){
  let overlay = document.getElementById('story-overlay');
  if (overlay) overlay.remove();

  const story = stories[index];
  const isOwn = story.uid === currentUser.uid;
  const liked = (story.likes || []).includes(currentUser.uid);
  registerStoryView(story);

  overlay = document.createElement('div');
  overlay.id = 'story-overlay';
  overlay.className = 'story-overlay';

  const muteOriginal = !!story.audioURL;
  const mediaTag = story.mediaType === 'video'
    ? `<video src="${story.mediaURL}" class="story-media" ${muteOriginal ? 'muted' : ''} autoplay playsinline></video>`
    : `<img src="${story.mediaURL}" class="story-media" />`;
  const audioTag = story.audioURL ? `<audio src="${story.audioURL}" autoplay></audio>` : '';
  const captionTag = story.caption ? `<div class="story-caption-overlay">${escapeHtml(story.caption)}</div>` : '';

  overlay.innerHTML = `
    <div class="story-overlay-header">
      <img class="avatar-sm" src="${story.userPhoto || defaultAvatar()}" />
      <span class="post-username">${escapeHtml(story.username)}</span>
      ${isOwn ? `<button class="story-close-btn" id="delete-story-btn" title="Supprimer">🗑</button>` : ''}
      <button class="story-close-btn">✕</button>
    </div>
    ${mediaTag}
    ${audioTag}
    ${captionTag}
    <div class="story-tap-zone story-tap-prev"></div>
    <div class="story-tap-zone story-tap-next"></div>
    ${isOwn ? `<button class="story-views-btn">👁 Voir qui a regardé</button>` : `
      <div class="story-reply-bar">
        <button class="story-like-btn ${liked ? 'liked' : ''}" data-liked="${liked}">${liked ? '♥' : '♡'}</button>
        <form class="story-reply-form">
          <input type="text" placeholder="Répondre à la story..." maxlength="200" />
          <button type="submit">➤</button>
        </form>
      </div>
    `}
  `;

  document.body.appendChild(overlay);

  overlay.querySelectorAll('.story-close-btn:not(#delete-story-btn)').forEach(btn => {
    btn.addEventListener('click', () => overlay.remove());
  });
  overlay.querySelector('.story-tap-next').addEventListener('click', () => {
    if (index < stories.length - 1) showStoryOverlay(stories, index + 1);
    else overlay.remove();
  });
  overlay.querySelector('.story-tap-prev').addEventListener('click', () => {
    if (index > 0) showStoryOverlay(stories, index - 1);
  });

  if (isOwn){
    overlay.querySelector('.story-views-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      openStoryViewersList(story.id);
    });
    overlay.querySelector('#delete-story-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      deleteStory(story.id, overlay);
    });
  } else {
    const likeBtn = overlay.querySelector('.story-like-btn');
    likeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleStoryLike(story.id, likeBtn.dataset.liked === 'true', story.uid, likeBtn);
    });
    overlay.querySelector('.story-reply-form').addEventListener('click', (e) => e.stopPropagation());
    overlay.querySelector('.story-reply-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const input = e.target.querySelector('input');
      const text = input.value.trim();
      if (!text) return;
      sendStoryReply(story, text);
      overlay.remove();
    });
  }

  if (story.mediaType === 'image' && !isOwn){
    setTimeout(() => {
      if (document.getElementById('story-overlay') === overlay){
        if (index < stories.length - 1) showStoryOverlay(stories, index + 1);
        else overlay.remove();
      }
    }, 6000);
  }
}
