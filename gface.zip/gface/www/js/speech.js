// ============================================================
// G-face — speech.js : reconnaissance vocale native (module Android)
// Utilisée pour la recherche vocale et la dictée de légendes/textes.
// Ce n'est PAS une transcription automatique du son d'une vidéo :
// c'est de la dictée en direct via le micro du téléphone.
// ============================================================

function getNativeSpeechRecognition(){
  return window.Capacitor?.Plugins?.SpeechRecognition || null;
}

async function startDictation(onResult, btn){
  const SpeechRecognition = getNativeSpeechRecognition();
  if (!SpeechRecognition){
    alert("La reconnaissance vocale n'est pas disponible dans cette version de l'application (module natif manquant).");
    return;
  }

  try{
    const { available } = await SpeechRecognition.available();
    if (!available){
      alert("La reconnaissance vocale n'est pas disponible sur cet appareil.");
      return;
    }

    await SpeechRecognition.requestPermissions();

    if (btn){ btn.disabled = true; btn.dataset.originalText = btn.textContent; btn.textContent = '🎙️ Écoute...'; }

    const result = await SpeechRecognition.start({
      language: 'fr-FR',
      maxResults: 1,
      prompt: 'Parle maintenant...',
      partialResults: false,
      popup: false
    });

    if (result && result.matches && result.matches.length > 0){
      onResult(result.matches[0]);
    } else {
      alert("Je n'ai rien entendu, réessaie.");
    }
  }catch(err){
    alert('Erreur de reconnaissance vocale : ' + (err.message || err));
  }finally{
    if (btn){ btn.disabled = false; btn.textContent = btn.dataset.originalText; }
  }
}
