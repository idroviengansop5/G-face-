// ============================================================
// G-face — speech.js : reconnaissance vocale partagée
// Utilisée pour la recherche vocale et la dictée de légendes/textes.
// Ce n'est PAS une transcription automatique du son d'une vidéo :
// c'est de la dictée en direct via le micro du téléphone.
// ============================================================

function getSpeechRecognition(){
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  return SpeechRecognition ? new SpeechRecognition() : null;
}

/**
 * Lance une écoute vocale ponctuelle et renvoie le texte reconnu via le callback.
 * btn : bouton à mettre à jour visuellement pendant l'écoute (optionnel).
 */
function startDictation(onResult, btn){
  const recognition = getSpeechRecognition();
  if (!recognition){
    alert("La reconnaissance vocale n'est pas disponible sur cet appareil.");
    return;
  }

  recognition.lang = 'fr-FR';
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;

  if (btn){ btn.disabled = true; btn.dataset.originalText = btn.textContent; btn.textContent = '🎙️ Écoute...'; }

  recognition.onresult = (event) => {
    const text = event.results[0][0].transcript;
    onResult(text);
  };

  recognition.onerror = (event) => {
    if (event.error !== 'aborted'){
      alert('Erreur de reconnaissance vocale : ' + event.error);
    }
  };

  recognition.onend = () => {
    if (btn){ btn.disabled = false; btn.textContent = btn.dataset.originalText; }
  };

  try{
    recognition.start();
  }catch(err){
    if (btn){ btn.disabled = false; btn.textContent = btn.dataset.originalText; }
    alert('Impossible de démarrer la reconnaissance vocale : ' + err.message);
  }
}
