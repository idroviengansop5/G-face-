// ============================================================
// G-face — hashtag.js : page dédiée à un hashtag
// ============================================================

document.getElementById('hashtag-back-btn').addEventListener('click', () => switchView('discover'));

async function openHashtagPage(tag){
  switchView('hashtag');
  document.getElementById('hashtag-title').textContent = '#' + tag;
  const list = document.getElementById('hashtag-list');
  list.innerHTML = '<p class="empty-sub" style="text-align:center;">Chargement...</p>';

  try{
    const snap = await db.collection('posts').orderBy('createdAt', 'desc').limit(200).get();
    const tagLower = tag.toLowerCase();
    const regex = new RegExp('#' + tagLower.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'i');

    const matches = [];
    snap.forEach(doc => {
      const p = doc.data();
      if (blockedUids.has(p.uid)) return;
      if (p.caption && regex.test(p.caption)) matches.push({ id: doc.id, data: p });
    });

    list.innerHTML = '';
    if (matches.length === 0){
      list.innerHTML = '<p class="empty-sub" style="text-align:center;">Aucune publication avec ce hashtag.</p>';
      return;
    }
    matches.forEach(m => list.appendChild(buildPostCard(m.id, m.data)));
  }catch(err){
    list.innerHTML = '<p class="empty-sub" style="text-align:center;">Erreur : ' + escapeHtml(err.message) + '</p>';
  }
}
