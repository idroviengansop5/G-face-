// ============================================================
// G-face — moderation.js : blocage d'utilisateurs et signalements
// ============================================================

let blockedUids = new Set();
let blocksUnsubscribe = null;

function initBlocks(){
  if (blocksUnsubscribe) blocksUnsubscribe();
  blocksUnsubscribe = db.collection('blocks')
    .where('blockerUid', '==', currentUser.uid)
    .onSnapshot(snap => {
      blockedUids = new Set();
      snap.forEach(doc => blockedUids.add(doc.data().blockedUid));
      // Réaffiche le fil pour cacher immédiatement les publications des personnes bloquées
      if (typeof initFeed === 'function') initFeed();
    }, err => console.error('Erreur blocages:', err));
}

async function isBlockedByOther(otherUid){
  try{
    const snap = await db.collection('blocks')
      .where('blockerUid', '==', otherUid)
      .where('blockedUid', '==', currentUser.uid)
      .limit(1)
      .get();
    return !snap.empty;
  }catch(err){
    console.error('Erreur vérification blocage:', err);
    return false;
  }
}

async function toggleBlock(targetUid){
  const btn = document.getElementById('up-block-btn');
  const alreadyBlocked = blockedUids.has(targetUid);

  if (alreadyBlocked){
    await db.collection('blocks').doc(`${currentUser.uid}_${targetUid}`).delete();
    btn.textContent = 'Bloquer';
  } else {
    if (!confirm("Bloquer cet utilisateur ? Vous ne verrez plus ses publications, et il/elle ne pourra plus t'envoyer de messages.")) return;
    await db.collection('blocks').doc(`${currentUser.uid}_${targetUid}`).set({
      blockerUid: currentUser.uid,
      blockedUid: targetUid,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    // Se désabonner automatiquement dans les deux sens n'est pas géré ici pour rester simple
    btn.textContent = 'Débloquer';
  }
}

async function reportContent(targetType, targetId, reportedUid){
  const reason = prompt('Pourquoi signales-tu ce contenu ? (spam, contenu inapproprié, harcèlement...)');
  if (reason === null) return;
  try{
    await db.collection('reports').add({
      targetType,
      targetId,
      reportedUid: reportedUid || null,
      reporterUid: currentUser.uid,
      reason: reason.trim() || 'Non précisé',
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    alert('Merci, ton signalement a été envoyé.');
  }catch(err){
    alert('Échec du signalement : ' + err.message);
  }
}
