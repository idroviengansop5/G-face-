// ============================================================
// G-face — account.js : changer son e-mail / mot de passe
// ============================================================

document.getElementById('change-email-btn').addEventListener('click', async () => {
  const newEmail = prompt('Nouvelle adresse e-mail :', currentUser.email || '');
  if (!newEmail || newEmail.trim() === '' || newEmail === currentUser.email) return;

  const password = prompt('Confirme ton mot de passe actuel pour continuer :');
  if (!password) return;

  try{
    const cred = firebase.auth.EmailAuthProvider.credential(currentUser.email, password);
    await currentUser.reauthenticateWithCredential(cred);
    await currentUser.updateEmail(newEmail.trim());
    await db.collection('users').doc(currentUser.uid).update({ email: newEmail.trim() });
    alert('Adresse e-mail mise à jour !');
  }catch(err){
    alert('Échec : ' + translateAccountError(err));
  }
});

document.getElementById('change-password-btn').addEventListener('click', async () => {
  const currentPassword = prompt('Mot de passe actuel :');
  if (!currentPassword) return;

  const newPassword = prompt('Nouveau mot de passe (6 caractères minimum) :');
  if (!newPassword) return;
  if (newPassword.length < 6){
    alert('Le nouveau mot de passe doit contenir au moins 6 caractères.');
    return;
  }

  try{
    const cred = firebase.auth.EmailAuthProvider.credential(currentUser.email, currentPassword);
    await currentUser.reauthenticateWithCredential(cred);
    await currentUser.updatePassword(newPassword);
    alert('Mot de passe mis à jour !');
  }catch(err){
    alert('Échec : ' + translateAccountError(err));
  }
});

function translateAccountError(err){
  const map = {
    'auth/wrong-password': 'Mot de passe actuel incorrect.',
    'auth/invalid-credential': 'Mot de passe actuel incorrect.',
    'auth/email-already-in-use': 'Cette adresse e-mail est déjà utilisée par un autre compte.',
    'auth/invalid-email': 'Adresse e-mail invalide.',
    'auth/weak-password': 'Le mot de passe doit contenir au moins 6 caractères.',
    'auth/requires-recent-login': 'Pour ta sécurité, reconnecte-toi puis réessaie.'
  };
  return map[err.code] || err.message;
}
