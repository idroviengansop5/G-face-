// ============================================================
// G-face — reminder.js : rappel quotidien de publication (notification locale)
// ============================================================

const REMINDER_ID = 1001;

function getLocalNotifications(){
  return window.Capacitor?.Plugins?.LocalNotifications || null;
}

async function initReminderToggle(){
  const toggle = document.getElementById('reminder-toggle-input');
  const enabled = localStorage.getItem('gface-reminder') === 'on';
  toggle.checked = enabled;

  toggle.addEventListener('change', async () => {
    const LocalNotifications = getLocalNotifications();
    if (!LocalNotifications){
      alert("Les rappels ne fonctionnent que dans l'application G-face installée sur ton téléphone (pas dans un navigateur).");
      toggle.checked = false;
      return;
    }

    if (toggle.checked){
      try{
        const perm = await LocalNotifications.requestPermissions();
        if (perm.display !== 'granted'){
          alert("Autorise les notifications pour G-face dans les paramètres de ton téléphone pour activer les rappels.");
          toggle.checked = false;
          return;
        }
        await LocalNotifications.schedule({
          notifications: [{
            id: REMINDER_ID,
            title: 'G-face',
            body: "N'oublie pas de publier quelque chose aujourd'hui sur G-face ! 🎥",
            schedule: { on: { hour: 18, minute: 0 }, repeats: true },
          }]
        });
        localStorage.setItem('gface-reminder', 'on');
      }catch(err){
        alert('Impossible de programmer le rappel : ' + err.message);
        toggle.checked = false;
      }
    } else {
      try{
        await LocalNotifications.cancel({ notifications: [{ id: REMINDER_ID }] });
      }catch(err){
        console.error('Erreur annulation rappel:', err);
      }
      localStorage.setItem('gface-reminder', 'off');
    }
  });
}

initReminderToggle();
