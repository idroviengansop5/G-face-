// ============================================================
// G-face — app.js : authentification + navigation
// ============================================================

let currentUser = null;      // objet auth Firebase
let currentUserData = null;  // document Firestore users/{uid}

const viewAuth = document.getElementById('view-auth');
const appShell = document.getElementById('app-shell');
const bottomNav = document.getElementById('bottom-nav');

// ---------- Bascule Connexion / Inscription ----------
document.getElementById('go-signup').addEventListener('click', (e) => {
  e.preventDefault();
  document.getElementById('login-form').classList.add('hidden');
  document.getElementById('signup-form').classList.remove('hidden');
  hideAuthError();
});
document.getElementById('go-login').addEventListener('click', (e) => {
  e.preventDefault();
  document.getElementById('signup-form').classList.add('hidden');
  document.getElementById('login-form').classList.remove('hidden');
  hideAuthError();
});

function showAuthError(msg){
  const el = document.getElementById('auth-error');
  el.textContent = msg;
  el.classList.remove('hidden');
}
function hideAuthError(){
  document.getElementById('auth-error').classList.add('hidden');
}

// ---------- Inscription ----------
document.getElementById('signup-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  hideAuthError();
  const username = document.getElementById('signup-username').value.trim();
  const email = document.getElementById('signup-email').value.trim();
  const password = document.getElementById('signup-password').value;

  try{
    const cred = await auth.createUserWithEmailAndPassword(email, password);
    await db.collection('users').doc(cred.user.uid).set({
      username,
      usernameLower: username.toLowerCase(),
      email,
      photoURL: '',
      status: '',
      bio: '',
      isPrivate: false,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
  }catch(err){
    showAuthError(translateAuthError(err));
  }
});

// ---------- Connexion ----------
document.getElementById('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  hideAuthError();
  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;
  try{
    await auth.signInWithEmailAndPassword(email, password);
  }catch(err){
    showAuthError(translateAuthError(err));
  }
});

function translateAuthError(err){
  const map = {
    'auth/email-already-in-use': "Cette adresse e-mail est déjà utilisée.",
    'auth/invalid-email': "Adresse e-mail invalide.",
    'auth/weak-password': "Le mot de passe doit contenir au moins 6 caractères.",
    'auth/user-not-found': "Aucun compte ne correspond à cette adresse.",
    'auth/wrong-password': "Mot de passe incorrect.",
    'auth/invalid-credential': "Identifiants incorrects.",
  };
  return map[err.code] || ("Erreur : " + err.message);
}

// ---------- Déconnexion ----------
document.getElementById('logout-btn').addEventListener('click', () => {
  auth.signOut();
});

// ---------- Écoute de l'état de connexion ----------
auth.onAuthStateChanged(async (user) => {
  if (user){
    currentUser = user;
    const doc = await db.collection('users').doc(user.uid).get();
    currentUserData = doc.exists ? doc.data() : null;

    viewAuth.classList.remove('active');
    appShell.classList.remove('hidden');
    bottomNav.classList.remove('hidden');

    initFeed();
    initProfile();
    initMessages();
    initNotifications();
    initStories();
    initFollowRequests();
    initBlocks();
    initUnreadBadge();
    initBookmarks();
  } else {
    currentUser = null;
    currentUserData = null;
    appShell.classList.add('hidden');
    bottomNav.classList.add('hidden');
    viewAuth.classList.add('active');
  }
});

// ---------- Navigation entre onglets ----------
const views = ['feed','upload','messages','chat','profile','discover','notifications','user-profile','follow-list','export','hashtag','likes-list','bookmarks','new-group'];

function switchView(name){
  views.forEach(v => {
    document.getElementById('view-' + v).classList.toggle('active', v === name);
  });
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.view === name);
  });
  if (name === 'profile') renderMyProfile();
  if (name === 'messages') renderChatsList();
  if (name === 'notifications') markNotificationsRead();
  if (name === 'discover') renderDiscoverDefault();
}

document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', () => switchView(btn.dataset.view));
});

document.getElementById('discover-btn').addEventListener('click', () => switchView('discover'));
document.getElementById('notif-btn').addEventListener('click', () => switchView('notifications'));

document.getElementById('chat-back-btn').addEventListener('click', () => {
  switchView('messages');
});
