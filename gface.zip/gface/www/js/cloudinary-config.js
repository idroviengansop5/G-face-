// ============================================================
// CONFIGURATION CLOUDINARY — G-face
// Utilisé pour stocker les vidéos et les photos de profil
// (remplace Firebase Storage, qui demande une carte bancaire)
// ============================================================

const CLOUDINARY_CLOUD_NAME = "ovbzxeud";
const CLOUDINARY_UPLOAD_PRESET = "gface_uploads";

/**
 * Envoie un fichier (vidéo ou image) vers Cloudinary avec suivi de progression.
 * resourceType: "video" ou "image"
 * onProgress: fonction appelée avec un pourcentage (0-100)
 * Retourne l'URL sécurisée du fichier hébergé.
 */
function uploadToCloudinary(file, resourceType, onProgress){
  return new Promise((resolve, reject) => {
    const url = `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/${resourceType}/upload`;
    const formData = new FormData();
    formData.append('file', file);
    formData.append('upload_preset', CLOUDINARY_UPLOAD_PRESET);

    const xhr = new XMLHttpRequest();
    xhr.open('POST', url, true);

    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable && onProgress){
        onProgress((e.loaded / e.total) * 100);
      }
    };

    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300){
        const response = JSON.parse(xhr.responseText);
        resolve(response.secure_url);
      } else {
        reject(new Error('Échec de l\'envoi vers Cloudinary (code ' + xhr.status + ')'));
      }
    };

    xhr.onerror = () => reject(new Error('Erreur réseau pendant l\'envoi.'));
    xhr.send(formData);
  });
}
