// ============================================================
// G-face — messages.js : recherche, liste de discussions, chat temps réel
// ============================================================

let currentChatId = null;
let currentChatWithUid = null;
let chatMessagesUnsubscribe = null;

function initMessages(){
  // écouteurs mis en place une seule fois
}

function chatIdFor(uidA, uidB){
  return [uidA, uidB].sort().join('_');
}

// ---------- Recherche d'utilisateurs ----------
document.getElementById('user-search-btn').addEventListener('click', searchUsers);
document.getElementById('user-search-input').addEventListener('keydown', (e) => {
  if (e.key === 'Enter'){ e.preventDefault(); searchUsers(); }
});

async function searchUsers(){
  const term = document.getElementById('user-search-input').value.trim().toLowerCase();
  const resultsBox = document.getElementById('user-search-results');
  resultsBox.innerHTML = '';
  if (!term) return;

  const snap = await db.collection('users')
    .where('usernameLower', '>=', term)
    .where('usernameLower', '<=', term + '\uf8ff')
    .limit(15)
    .get();

  snap.forEach(doc => {
    if (doc.id === currentUser.uid) return;
    const u = doc.data();
    const row = document.createElement('div');
    row.className = 'user-result-row';
    row.innerHTML = `
      <img class="avatar-sm" src="${u.photoURL || defaultAvatar()}" />
      <span>${escapeHtml(u.username)}</span>
    `;
    row.addEventListener('click', () => openChat(doc.id, u.username));
    resultsBox.appendChild(row);
  });

  if (snap.empty){
    resultsBox.innerHTML = '<p class="empty-sub">Aucun utilisateur trouvé.</p>';
  }
}

// ---------- Liste des discussions ----------
async function renderChatsList(){
  const list = document.getElementById('chats-list');
  const empty = document.getElementById('chats-empty');

  const snap = await db.collection('chats')
    .where('participants', 'array-contains', currentUser.uid)
    .orderBy('lastMessageAt', 'desc')
    .get();

  if (snap.empty){
    list.innerHTML = '';
    list.appendChild(empty);
    return;
  }

  list.innerHTML = '';
  for (const doc of snap.docs){
    const chat = doc.data();
    const otherUid = chat.participants.find(p => p !== currentUser.uid);
    const otherDoc = await db.collection('users').doc(otherUid).get();
    const other = otherDoc.data() || {};

    const row = document.createElement('div');
    row.className = 'chat-row';
    row.innerHTML = `
      <img class="avatar-sm" src="${other.photoURL || defaultAvatar()}" />
      <div>
        <div class="chat-row-name">${escapeHtml(other.username || 'Utilisateur')}</div>
        <div class="chat-row-last">${escapeHtml(chat.lastMessage || '')}</div>
      </div>
    `;
    row.addEventListener('click', () => openChat(otherUid, other.username));
    list.appendChild(row);
  }
}

// ---------- Ouvrir une conversation ----------
function openChat(otherUid, otherUsername){
  currentChatWithUid = otherUid;
  currentChatId = chatIdFor(currentUser.uid, otherUid);
  document.getElementById('chat-with-name').textContent = otherUsername || 'Utilisateur';
  document.getElementById('user-search-results').innerHTML = '';
  document.getElementById('user-search-input').value = '';

  switchView('chat');
  listenToChatMessages();
}

function listenToChatMessages(){
  if (chatMessagesUnsubscribe) chatMessagesUnsubscribe();

  chatMessagesUnsubscribe = db.collection('chats').doc(currentChatId)
    .collection('messages')
    .orderBy('createdAt', 'asc')
    .onSnapshot(snap => {
      const box = document.getElementById('chat-messages');
      box.innerHTML = '';
      snap.forEach(doc => {
        const m = doc.data();
        const bubble = document.createElement('div');
        bubble.className = 'msg-bubble ' + (m.senderId === currentUser.uid ? 'msg-mine' : 'msg-theirs');
        bubble.textContent = m.text;
        box.appendChild(bubble);
      });
      box.scrollTop = box.scrollHeight;
    });
}

// ---------- Envoyer un message ----------
document.getElementById('chat-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const input = document.getElementById('chat-input');
  const text = input.value.trim();
  if (!text || !currentChatId) return;
  input.value = '';

  const chatRef = db.collection('chats').doc(currentChatId);

  await chatRef.set({
    participants: [currentUser.uid, currentChatWithUid],
    lastMessage: text,
    lastMessageAt: firebase.firestore.FieldValue.serverTimestamp()
  }, { merge: true });

  await chatRef.collection('messages').add({
    senderId: currentUser.uid,
    text,
    createdAt: firebase.firestore.FieldValue.serverTimestamp()
  });

  sendNotification(currentChatWithUid, 'message', {});
});
