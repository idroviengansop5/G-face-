// ============================================================
// G-face — messages.js : discussions 1:1 et groupes, saisie en cours,
// accusés de lecture, photos, messages vocaux
// ============================================================

let currentChatId = null;
let currentChatWithUid = null;   // uniquement pour les discussions 1:1
let currentChatIsGroup = false;
let currentChatParticipants = [];
let chatMessagesUnsubscribe = null;
let chatDocUnsubscribe = null;
let typingTimeout = null;
let msgMediaRecorder = null;
let msgRecordedChunks = [];

function initMessages(){
  // écouteurs mis en place une seule fois (voir plus bas)
}

function chatIdFor(uidA, uidB){
  return [uidA, uidB].sort().join('_');
}

// ---------- Recherche d'utilisateurs (nouvelle discussion 1:1) ----------
document.getElementById('user-search-btn').addEventListener('click', searchUsers);
document.getElementById('user-search-input').addEventListener('keydown', (e) => {
  if (e.key === 'Enter'){ e.preventDefault(); searchUsers(); }
});

async function searchUsers(){
  const term = document.getElementById('user-search-input').value.trim().toLowerCase();
  const resultsBox = document.getElementById('user-search-results');
  resultsBox.innerHTML = '';
  if (!term) return;

  const snap = await db.collection('users')
    .where('usernameLower', '>=', term)
    .where('usernameLower', '<=', term + '\uf8ff')
    .limit(15)
    .get();

  snap.forEach(doc => {
    if (doc.id === currentUser.uid) return;
    const u = doc.data();
    const row = document.createElement('div');
    row.className = 'user-result-row';
    row.innerHTML = `
      <img class="avatar-sm" src="${u.photoURL || defaultAvatar()}" />
      <span>${escapeHtml(u.username)}</span>
    `;
    row.addEventListener('click', () => openChat(doc.id, u.username));
    resultsBox.appendChild(row);
  });

  if (snap.empty){
    resultsBox.innerHTML = '<p class="empty-sub">Aucun utilisateur trouvé.</p>';
  }
}

// ---------- Liste des discussions (1:1 et groupes) ----------
async function renderChatsList(){
  const list = document.getElementById('chats-list');
  const empty = document.getElementById('chats-empty');

  let snap;
  try{
    snap = await db.collection('chats')
      .where('participants', 'array-contains', currentUser.uid)
      .get();
  }catch(err){
    console.error('Erreur chargement conversations:', err);
    list.innerHTML = '<p class="empty-sub" style="text-align:center;">Erreur de chargement : ' + escapeHtml(err.message) + '</p>';
    return;
  }

  if (snap.empty){
    list.innerHTML = '';
    list.appendChild(empty);
    return;
  }

  const chats = [];
  snap.forEach(doc => chats.push({ id: doc.id, data: doc.data() }));
  chats.sort((a, b) => (b.data.lastMessageAt?.toMillis?.() || 0) - (a.data.lastMessageAt?.toMillis?.() || 0));

  list.innerHTML = '';
  for (const { id: chatId, data: chat } of chats){
    const row = document.createElement('div');
    row.className = 'chat-row';

    if (chat.isGroup){
      row.innerHTML = `
        <div class="avatar-sm group-avatar-icon">👥</div>
        <div>
          <div class="chat-row-name">${escapeHtml(chat.groupName || 'Groupe')}</div>
          <div class="chat-row-last">${escapeHtml(chat.lastMessage || '')}</div>
        </div>
      `;
      row.addEventListener('click', () => openGroupChat(chatId, chat.groupName, chat.participants));
    } else {
      const otherUid = chat.participants.find(p => p !== currentUser.uid);
      const otherDoc = await db.collection('users').doc(otherUid).get();
      const other = otherDoc.data() || {};
      row.innerHTML = `
        <img class="avatar-sm" src="${other.photoURL || defaultAvatar()}" />
        <div>
          <div class="chat-row-name">${escapeHtml(other.username || 'Utilisateur')}</div>
          <div class="chat-row-last">${escapeHtml(chat.lastMessage || '')}</div>
        </div>
      `;
      row.addEventListener('click', () => openChat(otherUid, other.username));
    }
    list.appendChild(row);
  }
}

// ---------- Ouvrir une conversation 1:1 ----------
function openChat(otherUid, otherUsername){
  currentChatWithUid = otherUid;
  currentChatId = chatIdFor(currentUser.uid, otherUid);
  currentChatIsGroup = false;
  currentChatParticipants = [currentUser.uid, otherUid];
  document.getElementById('chat-with-name').textContent = otherUsername || 'Utilisateur';
  document.getElementById('user-search-results').innerHTML = '';
  document.getElementById('user-search-input').value = '';

  switchView('chat');
  listenToChatMessages();
  listenToChatDoc();
  markChatAsRead();
}

// ---------- Ouvrir un groupe ----------
function openGroupChat(chatId, groupName, participants){
  currentChatId = chatId;
  currentChatWithUid = null;
  currentChatIsGroup = true;
  currentChatParticipants = participants || [];
  document.getElementById('chat-with-name').textContent = '👥 ' + (groupName || 'Groupe');

  switchView('chat');
  listenToChatMessages();
  listenToChatDoc();
  markChatAsRead();
}

function markChatAsRead(){
  if (!currentChatId) return;
  db.collection('chats').doc(currentChatId).set({
    [`lastSeen.${currentUser.uid}`]: firebase.firestore.FieldValue.serverTimestamp()
  }, { merge: true }).catch(err => console.error('Erreur marquage lu:', err));
}

// ---------- Écoute du document de discussion (saisie en cours + accusés de lecture) ----------
function listenToChatDoc(){
  if (chatDocUnsubscribe) chatDocUnsubscribe();
  chatDocUnsubscribe = db.collection('chats').doc(currentChatId).onSnapshot(doc => {
    if (!doc.exists) return;
    const chat = doc.data();
    updateTypingIndicator(chat);
    updateSeenIndicator(chat);
  });
}

function updateTypingIndicator(chat){
  const indicator = document.getElementById('typing-indicator');
  const typingMap = chat.typing || {};
  const now = Date.now();
  const othersTyping = Object.keys(typingMap)
    .filter(uid => uid !== currentUser.uid)
    .filter(uid => {
      const ts = typingMap[uid]?.toMillis?.() || 0;
      return now - ts < 5000; // considéré "en train d'écrire" pendant 5 secondes
    });

  if (othersTyping.length === 0){
    indicator.classList.add('hidden');
    return;
  }
  indicator.classList.remove('hidden');
  indicator.textContent = currentChatIsGroup ? 'Quelqu\'un est en train d\'écrire...' : 'En train d\'écrire...';
}

let lastSeenCache = null;
function updateSeenIndicator(chat){
  lastSeenCache = chat.lastSeen || {};
  // Réaffiche les accusés de lecture sur les bulles déjà affichées
  renderSeenBadges(chat);
}

function renderSeenBadges(chat){
  if (currentChatIsGroup) return; // on garde les accusés de lecture pour le 1:1 uniquement
  const box = document.getElementById('chat-messages');
  const myBubbles = box.querySelectorAll('.msg-mine');
  if (myBubbles.length === 0) return;
  const lastMine = myBubbles[myBubbles.length - 1];
  let seenTag = lastMine.querySelector('.msg-seen');

  const otherUid = currentChatParticipants.find(p => p !== currentUser.uid);
  const otherSeen = chat.lastSeen?.[otherUid]?.toMillis?.() || 0;
  const lastMsgAt = chat.lastMessageAt?.toMillis?.() || 0;

  if (otherSeen >= lastMsgAt && lastMsgAt > 0){
    if (!seenTag){
      seenTag = document.createElement('div');
      seenTag.className = 'msg-seen';
      lastMine.appendChild(seenTag);
    }
    seenTag.textContent = 'Vu ✓✓';
  } else if (seenTag){
    seenTag.remove();
  }
}

// ---------- Badge de messages non lus ----------
let unreadChatsUnsubscribe = null;

function initUnreadBadge(){
  if (unreadChatsUnsubscribe) unreadChatsUnsubscribe();
  unreadChatsUnsubscribe = db.collection('chats')
    .where('participants', 'array-contains', currentUser.uid)
    .onSnapshot(snap => {
      let unreadCount = 0;
      snap.forEach(doc => {
        const chat = doc.data();
        if (!chat.lastMessageAt || chat.lastSenderId === currentUser.uid) return;
        const lastSeen = chat.lastSeen?.[currentUser.uid];
        if (!lastSeen || lastSeen.toMillis() < chat.lastMessageAt.toMillis()){
          unreadCount++;
        }
      });
      const badge = document.getElementById('messages-badge');
      if (unreadCount > 0){
        badge.textContent = unreadCount > 9 ? '9+' : unreadCount;
        badge.classList.remove('hidden');
      } else {
        badge.classList.add('hidden');
      }
    }, err => console.error('Erreur badge messages:', err));
}

// ---------- Messages ----------
function listenToChatMessages(){
  if (chatMessagesUnsubscribe) chatMessagesUnsubscribe();

  chatMessagesUnsubscribe = db.collection('chats').doc(currentChatId)
    .collection('messages')
    .orderBy('createdAt', 'asc')
    .onSnapshot(snap => {
      const box = document.getElementById('chat-messages');
      box.innerHTML = '';
      snap.forEach(doc => {
        const m = doc.data();
        const isMine = m.senderId === currentUser.uid;
        const bubble = document.createElement('div');
        bubble.className = 'msg-bubble ' + (isMine ? 'msg-mine' : 'msg-theirs');

        if (currentChatIsGroup && !isMine){
          const nameTag = document.createElement('div');
          nameTag.className = 'msg-sender-name';
          nameTag.textContent = m.senderUsername || 'Utilisateur';
          bubble.appendChild(nameTag);
        }

        if (m.imageURL){
          const img = document.createElement('img');
          img.className = 'msg-image';
          img.src = m.imageURL;
          bubble.appendChild(img);
        }
        if (m.audioURL){
          const audio = document.createElement('audio');
          audio.className = 'msg-audio';
          audio.controls = true;
          audio.src = m.audioURL;
          bubble.appendChild(audio);
        }
        if (m.text){
          const textSpan = document.createElement('div');
          textSpan.textContent = m.text + (m.edited ? ' (modifié)' : '');
          bubble.appendChild(textSpan);
        }

        if (isMine){
          const actions = document.createElement('div');
          actions.className = 'msg-own-actions';
          actions.innerHTML = (m.imageURL || m.audioURL)
            ? `<button class="delete-msg-btn">🗑</button>`
            : `<button class="edit-msg-btn">✎</button><button class="delete-msg-btn">🗑</button>`;
          if (!m.imageURL && !m.audioURL){
            actions.querySelector('.edit-msg-btn').addEventListener('click', () => editMessage(doc.id, m.text));
          }
          actions.querySelector('.delete-msg-btn').addEventListener('click', () => deleteMessage(doc.id));
          bubble.appendChild(actions);
        }

        box.appendChild(bubble);
      });
      box.scrollTop = box.scrollHeight;
      if (lastSeenCache) renderSeenBadges({ lastSeen: lastSeenCache, lastMessageAt: null });
    });
}

async function editMessage(messageId, currentText){
  const newText = prompt('Modifier ton message :', currentText);
  if (newText === null) return;
  const trimmed = newText.trim();
  if (!trimmed) return;
  try{
    await db.collection('chats').doc(currentChatId).collection('messages').doc(messageId)
      .update({ text: trimmed, edited: true });
  }catch(err){
    alert('Échec de la modification : ' + err.message);
  }
}

async function deleteMessage(messageId){
  if (!confirm('Supprimer ce message ?')) return;
  try{
    await db.collection('chats').doc(currentChatId).collection('messages').doc(messageId).delete();
  }catch(err){
    alert('Échec de la suppression : ' + err.message);
  }
}

function notifyOtherParticipants(type, extra){
  currentChatParticipants
    .filter(uid => uid !== currentUser.uid)
    .forEach(uid => sendNotification(uid, type, extra || {}));
}

function isBlockedForChat(){
  if (currentChatIsGroup) return false; // pas de blocage géré pour les groupes
  return blockedUids.has(currentChatWithUid);
}

// ---------- Saisie en cours ----------
document.getElementById('chat-input').addEventListener('input', () => {
  if (!currentChatId) return;
  clearTimeout(typingTimeout);
  db.collection('chats').doc(currentChatId).set({
    [`typing.${currentUser.uid}`]: firebase.firestore.FieldValue.serverTimestamp()
  }, { merge: true }).catch(() => {});
});

// ---------- Envoyer une photo ----------
document.getElementById('chat-image-input').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file || !currentChatId) return;

  if (isBlockedForChat()){
    alert("Tu as bloqué cet utilisateur. Débloque-le d'abord pour lui envoyer un message.");
    return;
  }

  if (file.size > 10 * 1024 * 1024){
    alert('Image trop lourde (limite : 10 Mo).');
    return;
  }

  try{
    const imageURL = await uploadToCloudinary(file, 'image');
    const chatRef = db.collection('chats').doc(currentChatId);

    await chatRef.set({
      participants: currentChatParticipants,
      isGroup: currentChatIsGroup,
      lastMessage: '📷 Photo',
      lastMessageAt: firebase.firestore.FieldValue.serverTimestamp(),
      lastSenderId: currentUser.uid
    }, { merge: true });

    await chatRef.collection('messages').add({
      senderId: currentUser.uid,
      senderUsername: currentUserData?.username || 'Utilisateur',
      imageURL,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    notifyOtherParticipants('message', {});
  }catch(err){
    alert("Échec de l'envoi de la photo : " + err.message);
  }
});

// ---------- Message vocal ----------
document.getElementById('chat-voice-btn').addEventListener('click', async (e) => {
  const btn = e.currentTarget;

  if (msgMediaRecorder && msgMediaRecorder.state === 'recording'){
    msgMediaRecorder.stop();
    btn.textContent = '🎙️';
    return;
  }

  if (isBlockedForChat()){
    alert("Tu as bloqué cet utilisateur. Débloque-le d'abord pour lui envoyer un message.");
    return;
  }

  try{
    const SpeechRecognition = getNativeSpeechRecognition?.();
    if (SpeechRecognition){ try{ await SpeechRecognition.requestPermissions(); }catch(e){} }

    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    msgRecordedChunks = [];
    msgMediaRecorder = new MediaRecorder(stream);
    msgMediaRecorder.ondataavailable = (ev) => { if (ev.data.size > 0) msgRecordedChunks.push(ev.data); };
    msgMediaRecorder.onstop = async () => {
      stream.getTracks().forEach(t => t.stop());
      const blob = new Blob(msgRecordedChunks, { type: 'audio/webm' });
      await sendVoiceMessage(blob);
    };
    msgMediaRecorder.start();
    btn.textContent = '⏹';
  }catch(err){
    alert("Impossible d'accéder au micro : " + err.message);
  }
});

async function sendVoiceMessage(blob){
  if (!currentChatId) return;
  try{
    const audioURL = await uploadToCloudinary(blob, 'video');
    const chatRef = db.collection('chats').doc(currentChatId);

    await chatRef.set({
      participants: currentChatParticipants,
      isGroup: currentChatIsGroup,
      lastMessage: '🎙️ Message vocal',
      lastMessageAt: firebase.firestore.FieldValue.serverTimestamp(),
      lastSenderId: currentUser.uid
    }, { merge: true });

    await chatRef.collection('messages').add({
      senderId: currentUser.uid,
      senderUsername: currentUserData?.username || 'Utilisateur',
      audioURL,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    notifyOtherParticipants('message', {});
  }catch(err){
    alert("Échec de l'envoi du message vocal : " + err.message);
  }
}

// ---------- Envoyer un message texte ----------
document.getElementById('chat-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const input = document.getElementById('chat-input');
  const text = input.value.trim();
  if (!text || !currentChatId) return;

  if (isBlockedForChat()){
    alert("Tu as bloqué cet utilisateur. Débloque-le d'abord pour lui envoyer un message.");
    return;
  }

  input.value = '';

  const chatRef = db.collection('chats').doc(currentChatId);

  await chatRef.set({
    participants: currentChatParticipants,
    isGroup: currentChatIsGroup,
    lastMessage: text,
    lastMessageAt: firebase.firestore.FieldValue.serverTimestamp(),
    lastSenderId: currentUser.uid,
    [`typing.${currentUser.uid}`]: firebase.firestore.FieldValue.delete()
  }, { merge: true });

  await chatRef.collection('messages').add({
    senderId: currentUser.uid,
    senderUsername: currentUserData?.username || 'Utilisateur',
    text,
    createdAt: firebase.firestore.FieldValue.serverTimestamp()
  });

  notifyOtherParticipants('message', {});
});

// ============================================================
// Création de groupe
// ============================================================
let groupSelectedMembers = {}; // { uid: { username, photoURL } }

document.getElementById('new-group-btn').addEventListener('click', () => {
  groupSelectedMembers = {};
  document.getElementById('group-name-input').value = '';
  document.getElementById('group-member-search-input').value = '';
  document.getElementById('group-member-results').innerHTML = '';
  renderSelectedGroupMembers();
  switchView('new-group');
});

document.getElementById('new-group-back-btn').addEventListener('click', () => switchView('messages'));

let groupSearchDebounce = null;
document.getElementById('group-member-search-input').addEventListener('input', (e) => {
  clearTimeout(groupSearchDebounce);
  const term = e.target.value.trim().toLowerCase();
  groupSearchDebounce = setTimeout(() => searchGroupMembers(term), 300);
});

async function searchGroupMembers(term){
  const resultsBox = document.getElementById('group-member-results');
  resultsBox.innerHTML = '';
  if (!term) return;

  const snap = await db.collection('users')
    .where('usernameLower', '>=', term)
    .where('usernameLower', '<=', term + '\uf8ff')
    .limit(15)
    .get();

  snap.forEach(doc => {
    if (doc.id === currentUser.uid) return;
    if (groupSelectedMembers[doc.id]) return;
    const u = doc.data();
    const row = document.createElement('div');
    row.className = 'user-result-row';
    row.innerHTML = `<img class="avatar-sm" src="${u.photoURL || defaultAvatar()}" /><span>${escapeHtml(u.username)}</span>`;
    row.addEventListener('click', () => {
      groupSelectedMembers[doc.id] = { username: u.username, photoURL: u.photoURL || '' };
      renderSelectedGroupMembers();
      document.getElementById('group-member-search-input').value = '';
      resultsBox.innerHTML = '';
    });
    resultsBox.appendChild(row);
  });
}

function renderSelectedGroupMembers(){
  const box = document.getElementById('group-selected-members');
  box.innerHTML = '';
  Object.entries(groupSelectedMembers).forEach(([uid, u]) => {
    const chip = document.createElement('div');
    chip.className = 'group-member-chip';
    chip.innerHTML = `<span>${escapeHtml(u.username)}</span><button>✕</button>`;
    chip.querySelector('button').addEventListener('click', () => {
      delete groupSelectedMembers[uid];
      renderSelectedGroupMembers();
    });
    box.appendChild(chip);
  });
}

document.getElementById('create-group-btn').addEventListener('click', async () => {
  const groupName = document.getElementById('group-name-input').value.trim();
  const memberUids = Object.keys(groupSelectedMembers);

  if (!groupName){ alert('Donne un nom à ton groupe.'); return; }
  if (memberUids.length < 2){ alert('Ajoute au moins 2 membres pour créer un groupe.'); return; }

  try{
    const participants = [currentUser.uid, ...memberUids];
    const docRef = await db.collection('chats').add({
      isGroup: true,
      groupName,
      participants,
      createdBy: currentUser.uid,
      lastMessage: 'Groupe créé',
      lastMessageAt: firebase.firestore.FieldValue.serverTimestamp(),
      lastSenderId: currentUser.uid
    });
    openGroupChat(docRef.id, groupName, participants);
  }catch(err){
    alert('Échec de la création du groupe : ' + err.message);
  }
});
