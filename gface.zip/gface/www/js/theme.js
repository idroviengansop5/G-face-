// ============================================================
// G-face — theme.js : bascule thème clair / sombre
// ============================================================

function applyStoredTheme(){
  const stored = localStorage.getItem('gface-theme');
  if (stored === 'light'){
    document.documentElement.setAttribute('data-theme', 'light');
  }
}

document.getElementById('theme-toggle-input').addEventListener('change', (e) => {
  if (e.target.checked){
    document.documentElement.setAttribute('data-theme', 'light');
    localStorage.setItem('gface-theme', 'light');
  } else {
    document.documentElement.removeAttribute('data-theme');
    localStorage.setItem('gface-theme', 'dark');
  }
});

// Applique le thème sauvegardé dès le chargement, et coche l'interrupteur en conséquence
applyStoredTheme();
document.getElementById('theme-toggle-input').checked = localStorage.getItem('gface-theme') === 'light';
