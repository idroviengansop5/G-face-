// ============================================================
// G-face — notifications.js : notifications en temps réel (dans l'app)
// ============================================================

let notifUnsubscribe = null;

function initNotifications(){
  if (notifUnsubscribe) notifUnsubscribe();

  notifUnsubscribe = db.collection('notifications')
    .where('toUid', '==', currentUser.uid)
    .orderBy('createdAt', 'desc')
    .limit(50)
    .onSnapshot(snap => {
      renderNotifications(snap);
      updateNotifBadge(snap);
    }, err => console.error('Erreur notifications:', err));
}

function updateNotifBadge(snap){
  const badge = document.getElementById('notif-badge');
  let unread = 0;
  snap.forEach(doc => { if (!doc.data().read) unread++; });
  if (unread > 0){
    badge.textContent = unread > 9 ? '9+' : unread;
    badge.classList.remove('hidden');
  } else {
    badge.classList.add('hidden');
  }
}

function renderNotifications(snap){
  const list = document.getElementById('notifications-list');
  const empty = document.getElementById('notifications-empty');

  if (snap.empty){
    list.innerHTML = '';
    list.appendChild(empty);
    return;
  }

  list.innerHTML = '';
  snap.forEach(doc => {
    const n = doc.data();
    const item = document.createElement('div');
    item.className = 'notification-item' + (n.read ? '' : ' unread');

    let icon = '🔔';
    let text = '';
    if (n.type === 'like'){ icon = '❤️'; text = `<b>${escapeHtml(n.fromUsername)}</b> a aimé ta publication`; }
    else if (n.type === 'comment'){ icon = '💬'; text = `<b>${escapeHtml(n.fromUsername)}</b> a commenté : "${escapeHtml(n.text || '')}"`; }
    else if (n.type === 'message'){ icon = '✉️'; text = `<b>${escapeHtml(n.fromUsername)}</b> t'a envoyé un message`; }
    else if (n.type === 'follow'){ icon = '👤'; text = `<b>${escapeHtml(n.fromUsername)}</b> s'est abonné(e) à toi`; }
    else if (n.type === 'follow_request'){ icon = '🔒'; text = `<b>${escapeHtml(n.fromUsername)}</b> souhaite s'abonner à toi`; }

    item.innerHTML = `<span class="notif-icon">${icon}</span><span class="notif-text">${text}</span>`;
    list.appendChild(item);
  });
}

async function markNotificationsRead(){
  const snap = await db.collection('notifications')
    .where('toUid', '==', currentUser.uid)
    .where('read', '==', false)
    .get();
  const batch = db.batch();
  snap.forEach(doc => batch.update(doc.ref, { read: true }));
  if (!snap.empty) await batch.commit();
}

/**
 * Crée une notification pour un autre utilisateur.
 * N'envoie jamais de notification à soi-même.
 */
async function sendNotification(toUid, type, extra){
  if (!toUid || toUid === currentUser.uid) return;
  try{
    await db.collection('notifications').add({
      toUid,
      fromUid: currentUser.uid,
      fromUsername: currentUserData?.username || 'Utilisateur',
      type,
      read: false,
      createdAt: firebase.firestore.FieldValue.serverTimestamp(),
      ...extra
    });
  }catch(err){
    console.error('Erreur envoi notification:', err);
  }
}
