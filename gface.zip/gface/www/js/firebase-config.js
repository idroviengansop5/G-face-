// ============================================================
// CONFIGURATION FIREBASE — G-face
// ============================================================
// Remplace les valeurs ci-dessous par celles de TON projet Firebase.
// Elles se trouvent dans : Console Firebase > Paramètres du projet
// > Général > tes applications > Config SDK.
// (Storage n'est plus utilisé ici : les vidéos/photos passent par Cloudinary)
// ============================================================

const firebaseConfig = {
  apiKey: "REMPLACE_MOI",
  authDomain: "REMPLACE_MOI.firebaseapp.com",
  projectId: "REMPLACE_MOI",
  storageBucket: "REMPLACE_MOI.appspot.com",
  messagingSenderId: "REMPLACE_MOI",
  appId: "REMPLACE_MOI"
};

firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();
const db = firebase.firestore();
