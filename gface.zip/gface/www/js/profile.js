// ============================================================
// G-face — profile.js : profil, statut, photo, mes publications
// ============================================================

function initProfile(){
  // rien à écouter en continu ici ; on recharge à chaque ouverture de l'onglet
}

async function renderMyProfile(){
  const doc = await db.collection('users').doc(currentUser.uid).get();
  currentUserData = doc.data();

  document.getElementById('profile-avatar').src = currentUserData.photoURL || defaultAvatar();
  document.getElementById('profile-username').textContent = currentUserData.username || '';
  document.getElementById('profile-status-display').textContent = currentUserData.status || 'Aucun statut';
  document.getElementById('profile-status-input').value = currentUserData.status || '';
  document.getElementById('profile-bio-input').value = currentUserData.bio || '';
  document.getElementById('profile-private-input').checked = !!currentUserData.isPrivate;

  loadFollowCounts(currentUser.uid, 'my-followers-count', 'my-following-count');

  renderMyPosts();
}

document.getElementById('profile-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const status = document.getElementById('profile-status-input').value.trim();
  const bio = document.getElementById('profile-bio-input').value.trim();
  const isPrivate = document.getElementById('profile-private-input').checked;

  await db.collection('users').doc(currentUser.uid).update({ status, bio, isPrivate });
  currentUserData.status = status;
  currentUserData.bio = bio;
  currentUserData.isPrivate = isPrivate;
  document.getElementById('profile-status-display').textContent = status || 'Aucun statut';
});

document.getElementById('avatar-file').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  if (file.size > 5 * 1024 * 1024){
    alert('Image trop lourde (limite : 5 Mo).');
    return;
  }
  try{
    const url = await uploadToCloudinary(file, 'image');
    await db.collection('users').doc(currentUser.uid).update({ photoURL: url });
    currentUserData.photoURL = url;
    document.getElementById('profile-avatar').src = url;
  }catch(err){
    alert("Échec de l'envoi de la photo : " + err.message);
  }
});

let myPostsCache = [];
let galleryMode = 'list';

document.querySelectorAll('.gallery-toggle-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.gallery-toggle-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    galleryMode = btn.dataset.mode;
    renderGalleryFromCache();
  });
});

function renderGalleryFromCache(){
  const listEl = document.getElementById('my-posts-list');
  const gridEl = document.getElementById('my-posts-grid');

  if (galleryMode === 'grid'){
    listEl.classList.add('hidden');
    gridEl.classList.remove('hidden');
    gridEl.innerHTML = '';
    myPostsCache.forEach(p => {
      const cell = document.createElement('div');
      cell.className = 'posts-grid-item';
      cell.innerHTML = `
        <video src="${p.data.videoURL}" muted preload="metadata"></video>
        ${p.data.pinned ? '<span class="grid-pin">📌</span>' : ''}
      `;
      cell.addEventListener('click', () => openGridVideoViewer(p.data));
      gridEl.appendChild(cell);
    });
  } else {
    listEl.classList.remove('hidden');
    gridEl.classList.add('hidden');
    listEl.innerHTML = '';
    myPostsCache.forEach(p => listEl.appendChild(buildPostCard(p.id, p.data)));
  }
}

function openGridVideoViewer(post){
  const overlay = document.createElement('div');
  overlay.className = 'story-overlay';
  overlay.innerHTML = `
    <div class="story-overlay-header">
      <span class="post-username">${escapeHtml(post.username || '')}</span>
      <button class="story-close-btn">✕</button>
    </div>
    <video src="${post.videoURL}" class="story-media" controls autoplay playsinline></video>
  `;
  overlay.querySelector('.story-close-btn').addEventListener('click', () => overlay.remove());
  document.body.appendChild(overlay);
}

async function renderMyPosts(){
  const list = document.getElementById('my-posts-list');
  list.innerHTML = '';
  try{
    const snap = await db.collection('posts')
      .where('uid', '==', currentUser.uid)
      .get();

    if (snap.empty){
      list.innerHTML = '<p class="empty-sub" style="text-align:center;">Aucune publication.</p>';
      document.getElementById('my-posts-grid').innerHTML = '';
      myPostsCache = [];
      document.getElementById('stat-posts').textContent = '0';
      document.getElementById('stat-views').textContent = '0';
      document.getElementById('stat-likes').textContent = '0';
      return;
    }

    const posts = [];
    snap.forEach(doc => posts.push({ id: doc.id, data: doc.data() }));
    posts.sort((a, b) => {
      if (!!a.data.pinned !== !!b.data.pinned) return a.data.pinned ? -1 : 1;
      return (b.data.createdAt?.toMillis?.() || 0) - (a.data.createdAt?.toMillis?.() || 0);
    });
    myPostsCache = posts;
    renderGalleryFromCache();

    const totalViews = posts.reduce((sum, p) => sum + (p.data.views || 0), 0);
    const totalLikes = posts.reduce((sum, p) => sum + (p.data.likeCount ?? (p.data.likes || []).length), 0);
    document.getElementById('stat-posts').textContent = posts.length;
    document.getElementById('stat-views').textContent = totalViews;
    document.getElementById('stat-likes').textContent = totalLikes;
  }catch(err){
    console.error('Erreur chargement de mes publications:', err);
    list.innerHTML = '<p class="empty-sub" style="text-align:center;">Erreur de chargement : ' + escapeHtml(err.message) + '</p>';
  }
}

// ---------- Export des données personnelles ----------
document.getElementById('export-data-btn').addEventListener('click', async () => {
  switchView('export');
  const textarea = document.getElementById('export-textarea');
  textarea.value = 'Préparation de tes données...';

  try{
    const postsSnap = await db.collection('posts').where('uid', '==', currentUser.uid).get();
    const posts = [];
    postsSnap.forEach(doc => {
      const p = doc.data();
      posts.push({
        caption: p.caption || '',
        videoURL: p.videoURL,
        likes: (p.likes || []).length,
        comments: p.commentCount || 0,
        views: p.views || 0,
        publieLe: p.createdAt?.toDate ? p.createdAt.toDate().toISOString() : null
      });
    });

    const exportData = {
      profil: {
        nomUtilisateur: currentUserData.username,
        email: currentUserData.email,
        statut: currentUserData.status || '',
        bio: currentUserData.bio || '',
        compteCree: currentUserData.createdAt?.toDate ? currentUserData.createdAt.toDate().toISOString() : null
      },
      publications: posts,
      exporteLe: new Date().toISOString()
    };

    textarea.value = JSON.stringify(exportData, null, 2);
  }catch(err){
    textarea.value = 'Erreur lors de la préparation : ' + err.message;
  }
});

document.getElementById('export-back-btn').addEventListener('click', () => switchView('profile'));

document.getElementById('copy-export-btn').addEventListener('click', async () => {
  const textarea = document.getElementById('export-textarea');
  try{
    await navigator.clipboard.writeText(textarea.value);
    alert('Copié dans le presse-papiers !');
  }catch(err){
    textarea.select();
    alert("Sélectionne le texte manuellement et copie-le (Ctrl+C / appui long).");
  }
});
