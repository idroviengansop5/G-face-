// ============================================================
// G-face — profile.js : profil, statut, photo, mes publications
// ============================================================

function initProfile(){
  // rien à écouter en continu ici ; on recharge à chaque ouverture de l'onglet
}

async function renderMyProfile(){
  const doc = await db.collection('users').doc(currentUser.uid).get();
  currentUserData = doc.data();

  document.getElementById('profile-avatar').src = currentUserData.photoURL || defaultAvatar();
  document.getElementById('profile-username').textContent = currentUserData.username || '';
  document.getElementById('profile-status-display').textContent = currentUserData.status || 'Aucun statut';
  document.getElementById('profile-status-input').value = currentUserData.status || '';
  document.getElementById('profile-bio-input').value = currentUserData.bio || '';

  renderMyPosts();
}

document.getElementById('profile-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const status = document.getElementById('profile-status-input').value.trim();
  const bio = document.getElementById('profile-bio-input').value.trim();

  await db.collection('users').doc(currentUser.uid).update({ status, bio });
  currentUserData.status = status;
  currentUserData.bio = bio;
  document.getElementById('profile-status-display').textContent = status || 'Aucun statut';
});

document.getElementById('avatar-file').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  if (file.size > 5 * 1024 * 1024){
    alert('Image trop lourde (limite : 5 Mo).');
    return;
  }
  try{
    const url = await uploadToCloudinary(file, 'image');
    await db.collection('users').doc(currentUser.uid).update({ photoURL: url });
    currentUserData.photoURL = url;
    document.getElementById('profile-avatar').src = url;
  }catch(err){
    alert("Échec de l'envoi de la photo : " + err.message);
  }
});

async function renderMyPosts(){
  const list = document.getElementById('my-posts-list');
  list.innerHTML = '';
  const snap = await db.collection('posts')
    .where('uid', '==', currentUser.uid)
    .orderBy('createdAt', 'desc')
    .get();

  if (snap.empty){
    list.innerHTML = '<p class="empty-sub" style="text-align:center;">Aucune publication.</p>';
    return;
  }
  snap.forEach(doc => {
    list.appendChild(buildPostCard(doc.id, doc.data()));
  });
}
