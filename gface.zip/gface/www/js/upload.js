// ============================================================
// G-face — upload.js : publication d'une nouvelle vidéo
// ============================================================

document.getElementById('video-file').addEventListener('change', (e) => {
  const file = e.target.files[0];
  document.getElementById('file-drop-text').textContent = file ? file.name : 'Choisir une vidéo';
});

document.getElementById('upload-form').addEventListener('submit', async (e) => {
  e.preventDefault();

  const file = document.getElementById('video-file').files[0];
  const caption = document.getElementById('video-caption').value.trim();
  const submitBtn = document.getElementById('upload-submit-btn');
  const progressBar = document.getElementById('upload-progress');
  const progressFill = document.getElementById('upload-progress-fill');

  if (!file){
    alert('Choisis une vidéo à publier.');
    return;
  }
  // Limite raisonnable côté client (50 Mo) pour éviter les uploads trop lourds
  if (file.size > 50 * 1024 * 1024){
    alert('La vidéo est trop lourde (limite : 50 Mo).');
    return;
  }

  submitBtn.disabled = true;
  submitBtn.textContent = 'Publication en cours...';
  progressBar.classList.remove('hidden');

  try{
    const path = `videos/${currentUser.uid}/${Date.now()}_${file.name}`;
    const ref = storage.ref(path);
    const task = ref.put(file);

    task.on('state_changed', (snap) => {
      const pct = (snap.bytesTransferred / snap.totalBytes) * 100;
      progressFill.style.width = pct + '%';
    });

    await task;
    const videoURL = await ref.getDownloadURL();

    await db.collection('posts').add({
      uid: currentUser.uid,
      username: currentUserData?.username || 'Utilisateur',
      userPhoto: currentUserData?.photoURL || '',
      videoURL,
      storagePath: path,
      caption,
      likes: [],
      commentCount: 0,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    document.getElementById('upload-form').reset();
    document.getElementById('file-drop-text').textContent = 'Choisir une vidéo';
    progressFill.style.width = '0%';
    progressBar.classList.add('hidden');
    switchView('feed');
  }catch(err){
    console.error(err);
    alert("Échec de la publication : " + err.message);
  }finally{
    submitBtn.disabled = false;
    submitBtn.textContent = 'Publier';
  }
});
