// ============================================================
// G-face — upload.js : publication d'une nouvelle vidéo (via Cloudinary)
// ============================================================

document.getElementById('video-file').addEventListener('change', (e) => {
  const file = e.target.files[0];
  document.getElementById('file-drop-text').textContent = file ? file.name : 'Choisir une vidéo';
});

document.getElementById('upload-mic-btn').addEventListener('click', (e) => {
  startDictation((text) => {
    const textarea = document.getElementById('video-caption');
    textarea.value = (textarea.value ? textarea.value + ' ' : '') + text;
  }, e.currentTarget);
});

document.getElementById('upload-form').addEventListener('submit', async (e) => {
  e.preventDefault();

  const file = document.getElementById('video-file').files[0];
  const caption = document.getElementById('video-caption').value.trim();
  const submitBtn = document.getElementById('upload-submit-btn');
  const progressBar = document.getElementById('upload-progress');
  const progressFill = document.getElementById('upload-progress-fill');

  if (!file){
    alert('Choisis une vidéo à publier.');
    return;
  }
  if (file.size > 50 * 1024 * 1024){
    alert('La vidéo est trop lourde (limite : 50 Mo).');
    return;
  }

  submitBtn.disabled = true;
  submitBtn.textContent = 'Publication en cours...';
  progressBar.classList.remove('hidden');
  progressFill.style.width = '0%';

  try{
    const videoURL = await uploadToCloudinary(file, 'video', (pct) => {
      progressFill.style.width = pct + '%';
    });

    await db.collection('posts').add({
      uid: currentUser.uid,
      username: currentUserData?.username || 'Utilisateur',
      userPhoto: currentUserData?.photoURL || '',
      videoURL,
      caption,
      likes: [],
      commentCount: 0,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    document.getElementById('upload-form').reset();
    document.getElementById('file-drop-text').textContent = 'Choisir une vidéo';
    progressFill.style.width = '0%';
    progressBar.classList.add('hidden');
    switchView('feed');
  }catch(err){
    console.error(err);
    alert("Échec de la publication : " + err.message);
  }finally{
    submitBtn.disabled = false;
    submitBtn.textContent = 'Publier';
  }
});
